package com.ideit.visionova.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ideit.visionova.entities.RefreshToken;
import com.ideit.visionova.Jwt.*;
import com.ideit.visionova.repository.RoleRepository;
import com.ideit.visionova.repository.UserRepository;
import com.ideit.visionova.security.service.RefreshTokenService;
import com.ideit.visionova.security.service.UserDetailsImpl;

import jakarta.servlet.http.HttpServletRequest;

//@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {

    private static final Logger log = LoggerFactory.getLogger(AuthenticationController.class);
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    RefreshTokenService refreshTokenService;

    record LoginRequest(String login, String password) {
    };

    record UserInfoResponse(Long id, String username, List<String> roles, Long idCustomer) {
    };

    record SignupRequest(String login, String password) {
    };

    record MessageResponse(String message) {
    };

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Validated @RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(loginRequest.login, loginRequest.password));

        SecurityContextHolder.getContext().setAuthentication(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
        RefreshToken refreshToken = refreshTokenService.createRefreshToken(userDetails.getId());
        ResponseCookie refreshTokenCookie = jwtUtils.generateRefreshTokenCookie(refreshToken);

        List<String> roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                .header(HttpHeaders.SET_COOKIE, refreshTokenCookie.toString())
                .body(new UserInfoResponse(userDetails.getId(), userDetails.getUsername(), roles, userDetails.getId()));
    }

    @GetMapping("/whoami")
    public ResponseEntity<?> whoami() {
        UserDetailsImpl principal = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();

        List<String> roles = principal.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());

        return ResponseEntity.ok()
                .body(new UserInfoResponse(principal.getId(), principal.getUsername(), roles, principal.getId()));
    }

    @GetMapping("/hello")
    @PreAuthorize("hasRole('PUBLIC')")
    public ResponseEntity<?> test() {
        UserDetailsImpl principal = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();

        return ResponseEntity.ok()
                .body(new MessageResponse("Hello " + principal.getUsername() + " " + principal.getAuthorities()));
    }

    @PostMapping("/signout")
    public ResponseEntity<?> logoutUser() {
        ResponseCookie cookie = jwtUtils.getCleanJwtCookie();
        ResponseCookie refreshTokenCookie = jwtUtils.getCleanJwtRefreshTokenCookie();

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString())
                .header(HttpHeaders.SET_COOKIE, refreshTokenCookie.toString())
                .body(new MessageResponse("You've been signed out!"));
    }

    @PostMapping("/refreshtoken")
    public ResponseEntity<?> refreshtoken(HttpServletRequest request) {
        try {
            // Obtener el JWT de las cookies o encabezado
            String jwt = jwtUtils.getJwtFromCookies(request);
            if (jwt == null) {
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    jwt = authHeader.substring(7);
                    log.debug("JWT retrieved from Authorization header");
                } else {
                    log.warn("JWT is missing in cookies and Authorization header");
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("JWT is missing");
                }
            }

            // Buscar el token de refresh
            Optional<RefreshToken> refreshTokenOptional = refreshTokenService.findByToken(jwt);
            if (refreshTokenOptional.isEmpty()) {
                log.warn("Refresh token not found for provided JWT");
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Refresh token not found");
            }

            RefreshToken refreshToken = refreshTokenOptional.get();

            // Verificar expiración del token de refresh
            if (refreshTokenService.verifyExpiration(refreshToken) == null) {
                log.warn("Refresh token has expired");
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Refresh token expired");
            }

            // Generar nuevo JWT
            String newJwt = jwtUtils.generateTokenFromUsername(refreshToken.getUser().getLogin());
            log.debug("New JWT generated successfully");

            // Generar las cookies
            ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(newJwt);
            if (jwtCookie == null) {
                log.error("Failed to generate JWT cookie");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate JWT cookie");
            }
            ResponseCookie refreshTokenCookie = jwtUtils.generateRefreshTokenCookie(refreshToken);

            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                    .header(HttpHeaders.SET_COOKIE, refreshTokenCookie.toString())
                    .body(new MessageResponse("Hello again " + refreshToken.getUser().getLogin()));
        } catch (Exception e) {
            log.error("Internal server error: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Internal server error: " + e.getMessage());
        }
    }

}
