package com.ideit.visionova.controller;

import com.ideit.visionova.entities.AnalysisProcessTemplate;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.AnalysisProcessTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/analysis-process-templates")
@RequiredArgsConstructor
public class AnalysisProcessTemplateController {

    private final AnalysisProcessTemplateService analysisProcessTemplateService;

    // Create Analysis Process Template
    @PostMapping
    public ResponseEntity<AnalysisProcessTemplate> createAnalysisProcessTemplate(@RequestBody AnalysisProcessTemplate analysisProcessTemplate,
                                                                                @RequestParam Long userId) {
        User user = new User();  // Asumimos que se obtiene el User por ID desde tu servicio o repositorio
        user.setId(userId);
        AnalysisProcessTemplate createdTemplate = analysisProcessTemplateService.createAnalysisProcessTemplate(analysisProcessTemplate, user);
        return new ResponseEntity<>(createdTemplate, HttpStatus.CREATED);
    }

    // Modify Analysis Process Template
    @PutMapping("/{id}")
    public ResponseEntity<AnalysisProcessTemplate> modifyAnalysisProcessTemplate(@PathVariable Long id, 
                                                                                @RequestBody AnalysisProcessTemplate analysisProcessTemplate,
                                                                                @RequestParam Long userId) {
        User user = new User();  // Asumimos que se obtiene el User por ID
        user.setId(userId);
        analysisProcessTemplate.setId(id); // Nos aseguramos de actualizar la entidad correcta
        AnalysisProcessTemplate updatedTemplate = analysisProcessTemplateService.modifyAnalysisProcessTemplates(analysisProcessTemplate, user);
        return updatedTemplate != null 
            ? new ResponseEntity<>(updatedTemplate, HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Disable Analysis Process Template
    @PatchMapping("/{id}/disable")
    public ResponseEntity<AnalysisProcessTemplate> disableAnalysisProcessTemplate(@PathVariable Long id, @RequestParam Long userId) {
        User user = new User();  // Asumimos que se obtiene el User por ID
        user.setId(userId);
        Optional<AnalysisProcessTemplate> disabledTemplate = analysisProcessTemplateService.findById(id)
                .map(template -> analysisProcessTemplateService.disableAnalysisProcessTemplate(template, user));
        return disabledTemplate.isPresent() 
            ? new ResponseEntity<>(disabledTemplate.get(), HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Get Analysis Process Template by ID
    @GetMapping("/{id}")
    public ResponseEntity<AnalysisProcessTemplate> getAnalysisProcessTemplate(@PathVariable Long id) {
        Optional<AnalysisProcessTemplate> analysisProcessTemplate = analysisProcessTemplateService.findById(id);
        return analysisProcessTemplate.map(template -> new ResponseEntity<>(template, HttpStatus.OK))
                                     .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Get all enabled Analysis Process Templates (puede expandirse para paginación)
    @GetMapping
    public ResponseEntity<Iterable<AnalysisProcessTemplate>> getAllAnalysisProcessTemplates() {
        Iterable<AnalysisProcessTemplate> templates = analysisProcessTemplateService.findByEnabled(true);
        return new ResponseEntity<>(templates, HttpStatus.OK);
    }
}