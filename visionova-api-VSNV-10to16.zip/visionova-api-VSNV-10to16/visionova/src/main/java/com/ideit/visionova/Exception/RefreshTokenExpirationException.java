package com.ideit.visionova.Exception;

public class RefreshTokenExpirationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RefreshTokenExpirationException(String token) {
        super(String.format("Refresh token [%s] has expired", token));
    }
}
