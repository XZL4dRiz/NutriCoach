package com.ideit.visionova.filter;


import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ideit.visionova.Jwt.JwtUtils;
import com.ideit.visionova.security.service.UserDetailsServiceImpl;

import jakarta.servlet.http.HttpServletRequest;


public class AuthTokenFilter extends OncePerRequestFilter {
  @Autowired
  private JwtUtils jwtUtils;

  @Autowired
  private UserDetailsServiceImpl userDetailsService;

  private static final Logger logger = LoggerFactory.getLogger(AuthTokenFilter.class);
  
  @SuppressWarnings("null")
  @Override
  protected void doFilterInternal(jakarta.servlet.http.HttpServletRequest request,
  		jakarta.servlet.http.HttpServletResponse response, jakarta.servlet.FilterChain filterChain)
  		throws jakarta.servlet.ServletException, IOException {
    try {
      logger.info(request.getRequestURL().toString());
      String jwt = parseJwt(request);
      if (jwt !=null) {
    	 if (jwt != null && jwtUtils.validateJwtToken(jwt)) {
    		 
	        String username = jwtUtils.getUserNameFromJwtToken(jwt);
	        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
	        UsernamePasswordAuthenticationToken authentication = 
	            new UsernamePasswordAuthenticationToken(userDetails,
	                                                    null,
	                                                    userDetails.getAuthorities());
	        
	        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
	        SecurityContextHolder.getContext().setAuthentication(authentication);
	     }
      }
      
    } catch (Exception e) {
      logger.error("Cannot set user authentication: {}", e);
    }

    filterChain.doFilter(request, response);
  }

  private String parseJwt(HttpServletRequest request) {
    String jwt = jwtUtils.getJwtFromCookies(request);
    return jwt;
  }


}