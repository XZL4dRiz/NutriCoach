package com.ideit.visionova.service;

import java.util.List;
import java.util.Optional;

import com.ideit.visionova.entities.Template;
import com.ideit.visionova.entities.User;


public interface TemplateService {

    /**
    * Recupera todos los parámetros globales.
    * 
    * @return Lista de parámetros globales.
    */
    List<Template> getAll();
    // Método para crear una nueva plantilla
    public Template createTemplate(Template template, User user);

    // Método para editar una plantilla existente
    public Template editTemplate(Template template, User user);

    // Método para deshabilitar una plantilla
    public Template disableTemplate(Template template, User user);

    // Método para buscar una plantilla por su ID
    public Optional<Template> findById(Long id);
}
