
package com.ideit.visionova.repository;

import com.ideit.visionova.entities.AnalysisProcessTemplate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Set;

public interface AnalysisProcessTemplateRepository extends CrudRepository<AnalysisProcessTemplate, Long>, PagingAndSortingRepository<AnalysisProcessTemplate, Long> {

    Page<AnalysisProcessTemplate> findByParametersLikeAndEnabled(String parameters, Boolean enabled, Pageable pageable);

    Page<AnalysisProcessTemplate> findByEnabled(Boolean enabled, Pageable pageable);

    Page<AnalysisProcessTemplate> findByEnabledAndIdIn(Boolean enabled, Set<Long> ids, Pageable pageable);

    Iterable<AnalysisProcessTemplate> findByEnabled(Boolean enabled);

    Iterable<AnalysisProcessTemplate> findByIdAndEnabled(Long id, Boolean enabled); 
}
