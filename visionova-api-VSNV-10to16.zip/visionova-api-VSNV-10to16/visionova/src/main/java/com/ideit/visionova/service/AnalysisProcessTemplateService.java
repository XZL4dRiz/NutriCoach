package com.ideit.visionova.service;

import java.util.Optional;

import com.ideit.visionova.entities.AnalysisProcessTemplate;
import com.ideit.visionova.entities.User;

public interface AnalysisProcessTemplateService {

    public AnalysisProcessTemplate createAnalysisProcessTemplate(AnalysisProcessTemplate analysisProcessTemplate, User user);

    public AnalysisProcessTemplate modifyAnalysisProcessTemplates(AnalysisProcessTemplate analysisProcessTemplate, User user);

    public AnalysisProcessTemplate disableAnalysisProcessTemplate(AnalysisProcessTemplate analysisProcessTemplate, User user);

    public Optional<AnalysisProcessTemplate> findById(Long id);

    public Iterable<AnalysisProcessTemplate> findByEnabled(Boolean enabled);

}