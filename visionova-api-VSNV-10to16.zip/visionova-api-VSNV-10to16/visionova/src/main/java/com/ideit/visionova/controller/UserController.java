package com.ideit.visionova.controller;

import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.UserService;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user, @RequestParam Long createdById) {
        // Assume that createdById is the ID of the user who is creating this new user
        User createdBy = new User();
        createdBy.setId(createdById);

        User createdUser = userService.createUser(user, createdBy);
        return ResponseEntity.ok(createdUser);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> modifyUser(@PathVariable Long id, @RequestBody User user, @RequestParam Long modifiedById) {
        // Updating user requires the ID of the user making the modification
        user.setId(id); // Ensure the ID from path is set on the user object
        User modifiedBy = new User();
        modifiedBy.setId(modifiedById);

        User modifiedUser = userService.modifyUser(user, modifiedBy);
        if (modifiedUser != null) {
            return ResponseEntity.ok(modifiedUser);
        }
        return ResponseEntity.notFound().build();
    }

    @PatchMapping("/{id}/disable")
    public ResponseEntity<User> disableUser(@PathVariable Long id, @RequestParam Long disabledById) {
        User user = new User();
        user.setId(id); // Set the ID of the user to be disabled
        User disabledBy = new User();
        disabledBy.setId(disabledById);

        User disabledUser = userService.disableUser(user, disabledBy);
        if (disabledUser != null) {
            return ResponseEntity.ok(disabledUser);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.findById(id);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
