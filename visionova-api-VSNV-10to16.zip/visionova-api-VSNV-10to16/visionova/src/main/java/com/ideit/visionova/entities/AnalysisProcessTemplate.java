package com.ideit.visionova.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "analysis_process_template")
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class AnalysisProcessTemplate implements CrudEntity{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    @Column(name = "id")
    private Long id;

    @JsonIgnore
    @JoinColumn(name = "analysis_process_id")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private AnalysisProcess analysisProcess;

    @Transient
    private Long analysisProcessId;

    @JsonProperty("analysisProcessId")
    public void setanalysisProcessId(Long analysisProcessId){
        this.analysisProcessId = analysisProcessId;
    }

    @JsonProperty("analysisProcessId")
    public Long getanalysisProcessId(){
        if (analysisProcessId!=null) 
            return analysisProcessId;
        if (analysisProcess!=null)
            return analysisProcess.getId();
        else return null;
    }

    @JsonIgnore
    @JoinColumn(name = "template_id")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private Template template;

    @Transient
    private Long templateId;

    @JsonProperty("templateId")
    public void settemplateId(Long templateId){
        this.templateId = templateId;
    }

    @JsonProperty("templateId")
    public Long gettemplateId(){
        if (templateId!=null) 
            return templateId;
        if (template!=null)
            return template.getId();
        else return null;
    }



    @Getter
    @Setter
    @Column(name = "parameters", nullable = false)
    private String parameters;

    @Column(name = "created_at", nullable = false)
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "created_by", nullable = false)
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User createdBy;

    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JoinColumn(name = "modified_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User modifiedBy;

    @Column(name = "disabled_at")
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    @Setter
    private Date disabledAt;

    @JoinColumn(name = "disabled_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;
}