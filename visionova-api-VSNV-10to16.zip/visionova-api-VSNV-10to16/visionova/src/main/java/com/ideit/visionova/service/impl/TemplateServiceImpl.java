package com.ideit.visionova.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ideit.visionova.Exception.TemplateNotFoundException;
import com.ideit.visionova.entities.Template;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.TemplateRepository;
import com.ideit.visionova.service.TemplateService;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class TemplateServiceImpl extends CrudServiceImpl implements TemplateService {
    private final EntityManager entityManager;
    private final TemplateRepository templateRepository;

    @Override
    public List<Template> getAll() {
        // Convertir Iterable<Template> a List<Template>
        List<Template> templates = new ArrayList<>();
        templateRepository.findAll().forEach(templates::add); // Rellenamos la lista

        // Filtrar los templates para obtener solo los habilitados (donde `disabledAt`
        // es null)
        return templates.stream()
                .filter(template -> template.getDisabledAt() == null) // Filtra los templates habilitados
                .collect(Collectors.toList()); // Recoge los resultados filtrados en una lista
    }

    @Transactional
    @Override
    public Template createTemplate(Template template, User user) {
        log.debug("createTemplate");
        // Recuperar al usuario desde el EntityManager
        user = entityManager.find(User.class, user.getId());
        fillCreationData(template, user); // Completar datos de creación
        checkInsertPreconditions(template); // Verificar condiciones de inserción
        Template saved = templateRepository.save(template); // Guardar el template
        return saved;
    }

    @Transactional
    @Override
    public Template editTemplate(Template template, User user) {
        Optional<Template> findById = templateRepository.findById(template.getId());
        if (findById.isPresent()) {
            Template current = findById.get();
            checkEditPreconditions(template, current); // Lógica para validar si se puede editar
            restoreCrudEntityDataWithCurrentEntity(current, template);
            user = entityManager.find(User.class, user.getId());
            fillModificationData(template, user); // Rellenar datos de modificación
            // Guarda el template actualizado y retorna el objeto guardado
            Template savedTemplate = templateRepository.save(template);
            return savedTemplate;
        } else {
            throw new TemplateNotFoundException("Template not found for ID " + template.getId());
        }
    }

    private void checkInsertPreconditions(Template template) {
        checkNamePrecondition(template); // Verificar precondiciones para el nombre
    }

    private void checkNamePrecondition(Template template) {
        Page<Template> existingTemplatePage = templateRepository
                .findByTemplateNameLikeAndEnabled(template.getTemplateName(), true, Pageable.unpaged());
    
        if (existingTemplatePage != null && existingTemplatePage.hasContent()) {
            // Lanza IllegalStateException en vez de RuntimeException
            throw new IllegalStateException("Template with the same name already exists.");
        }
    }
    

    private void checkEditPreconditions(Template template, Template current) {
        if (!current.getTemplateName().equalsIgnoreCase(template.getTemplateName())) {
            checkNamePrecondition(template); // Verificar precondiciones de nombre si se cambia
        }
    }

    @Transactional
    @Override
    public Template disableTemplate(Template template, User user) {
        Optional<Template> findById = templateRepository.findById(template.getId());
        if (findById.isPresent()) {
            Template current = findById.get();
            // Actualiza la fecha de deshabilitación
            current.setDisabledAt(new java.util.Date()); // Establece la fecha actual como la fecha de deshabilitación
            user = entityManager.find(User.class, user.getId());
            fillDisabilitationData(current, user); // Lógica adicional para deshabilitar, si es necesario
            // Guarda el template con la fecha de deshabilitación
            Template updatedTemplate = templateRepository.save(current);
            return updatedTemplate;
        }
        throw new TemplateNotFoundException("Template not found for ID " + template.getId());
    }

    @Override
    public Optional<Template> findById(Long id) {
        return templateRepository.findById(id); // Devolver Optional de Template
    }
}
