package com.ideit.visionova.entities;

import java.time.Instant;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "refresh_token")
@ToString
@NoArgsConstructor
@EqualsAndHashCode
public class RefreshToken {

    @Id
    @Getter
    @Setter
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @Getter
    @Setter
    private User user;

    @Column(nullable = false, unique = true)
    @Getter
    @Setter
    private String token;

    @Column(nullable = false)
    @Getter
    @Setter
    private Instant expiryDate;

    // Método para verificar si el token ha expirado
    public boolean isExpired() {
        return expiryDate.isBefore(Instant.now());
    }
}
