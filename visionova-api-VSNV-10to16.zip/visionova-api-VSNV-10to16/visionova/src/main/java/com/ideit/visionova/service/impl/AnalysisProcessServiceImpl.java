package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.AnalysisProcess;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.AnalysisProcessRepository;
import com.ideit.visionova.service.AnalysisProcessService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class AnalysisProcessServiceImpl extends CrudServiceImpl implements AnalysisProcessService {

    @PersistenceContext
    private EntityManager entityManager;

    private final AnalysisProcessRepository analysisProcessRepository;

    @Transactional
    @Override
    public AnalysisProcess createAnalysisProcess(AnalysisProcess analysisProcess, User user) {
        log.debug("createAnalysisProcess");
        user = entityManager.find(User.class, user.getId());
        fillCreationData(analysisProcess, user);
        checkInsertPreconditions(analysisProcess);
        return analysisProcessRepository.save(analysisProcess);
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional
    @Override
    public AnalysisProcess modifyAnalysisProcess(AnalysisProcess analysisProcess, User user) {
        log.debug("modifyAnalysisProcess");
        Optional<AnalysisProcess> findById = analysisProcessRepository.findById(analysisProcess.getId());
        if (findById.isPresent()) {
            AnalysisProcess current = findById.get();
            checkEditPreconditions(analysisProcess, current);
            restoreCrudEntityDataWithCurrentEntity(current, analysisProcess);
            user = entityManager.find(User.class, user.getId());
            fillModificationData(analysisProcess, user);
            return entityManager.merge(analysisProcess);
        }
        return null;
    }

    @Transactional
    @Override
    public AnalysisProcess disableAnalysisProcess(AnalysisProcess analysisProcess, User user) {
        log.debug("disableAnalysisProcess");
        Optional<AnalysisProcess> findById = analysisProcessRepository.findById(analysisProcess.getId());
        if (findById.isPresent()) {
            AnalysisProcess current = findById.get();
            user = entityManager.find(User.class, user.getId());
            fillDisabilitationData(current, user);
            return entityManager.merge(current);
        }
        return null;
    }

    private void checkInsertPreconditions(AnalysisProcess analysisProcess) {
        checkSourcePrecondition(analysisProcess);
    }

    private void checkSourcePrecondition(AnalysisProcess analysisProcess) {
        analysisProcessRepository.findByNameLikeAndEnabled(analysisProcess.getName(), true, Pageable.unpaged());
    }

    @Override
    public Optional<AnalysisProcess> findById(Long id) {
        log.debug("findById");
        return analysisProcessRepository.findById(id);
    }

    private void checkEditPreconditions(AnalysisProcess analysisProcess, AnalysisProcess current) {
        if (!current.getName().equalsIgnoreCase(analysisProcess.getName())) {
            checkSourcePrecondition(analysisProcess);
        }
    }

    @Override
    public Iterable<AnalysisProcess> findByEnabled(Boolean enabled) {
        log.debug("findByEnabled");
        return analysisProcessRepository.findByEnabled(enabled);
    }
}
