package com.ideit.visionova.service.impl;

import com.ideit.visionova.Exception.CameraNotFoundException;
import com.ideit.visionova.Exception.UserNotFoundException;
import com.ideit.visionova.entities.Camera;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.CameraRepository;
import com.ideit.visionova.service.CameraService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class CameraServiceImpl extends CrudServiceImpl implements CameraService {

    @PersistenceContext
    private EntityManager entityManager;

    private final CameraRepository cameraRepository;

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional
    @Override
    public Camera createCamera(Camera camera, User user){
        log.debug("createCamera");
        user = entityManager.find(User.class, user.getId());
        fillCreationData(camera, user);
        checkInsertPreconditions(camera);
        return cameraRepository.save(camera);
    }
    public Camera modifyCamera(Camera camera, User user) {
        Optional<Camera> existingCameraOpt = cameraRepository.findById(camera.getId());
        if (existingCameraOpt.isEmpty()) {
            throw new CameraNotFoundException("Camera not found");
        }
    
        Camera existingCamera = existingCameraOpt.get();
        existingCamera.setSource(camera.getSource()); // Modify as needed
    
        // You may want to add further logic here to update other properties if needed.
        Camera updatedCamera = cameraRepository.save(existingCamera);
    
        return updatedCamera; // Ensure the modified camera is returned
    }
    

    public Camera disableCamera(Camera camera, User user) {
        // Ensure the user is found and the camera exists
        User foundUser = entityManager.find(User.class, user.getId());
        if (foundUser == null) {
            throw new UserNotFoundException("User not found");
        }
    
        Optional<Camera> existingCameraOpt = cameraRepository.findById(camera.getId());
        if (existingCameraOpt.isEmpty()) {
            throw new CameraNotFoundException("Camera not found");
        }
    
        Camera existingCamera = existingCameraOpt.get();
        existingCamera.setActive(false); // Mark the camera as disabled
        cameraRepository.save(existingCamera); // Save the camera
    
        return existingCamera; // Return the updated camera
    }
    
    

    private void checkInsertPreconditions(Camera camera){
        checkSourcePrecondition(camera);
    }

    private void checkSourcePrecondition(Camera camera) {
        cameraRepository.findBySourceLikeAndEnabled(camera.getSource(), true, Pageable.unpaged());
    }

    @Override
    public Optional<Camera> findById(Long id) {
        log.debug("findById");
        return cameraRepository.findById(id);
    }

    public Page<Camera> findAll(Pageable pageable) {
        log.debug("findAll - Obtaining all cameras with pagination");
        return cameraRepository.findAll(pageable);
    }
}

