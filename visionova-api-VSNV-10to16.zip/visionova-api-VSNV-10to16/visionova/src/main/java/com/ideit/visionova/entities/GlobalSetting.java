package com.ideit.visionova.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "global_setting")
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class GlobalSetting implements CrudEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @Getter
    @Setter
    private Long id;

    @Column(name = "name", nullable = false, length = 50)
    @Getter
    @Setter
    private String name;

    @Column(name = "value", nullable = false, length = 255)
    @Getter
    @Setter
    private String value;

    @Column(name = "description", columnDefinition = "TEXT")
    @Getter
    @Setter
    private String description;

    @JsonIgnore
    @Column(name = "created_at", nullable = false)
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JsonIgnore
    @JoinColumn(name = "created_by")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private User createdBy;

    @JsonIgnore
    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JsonIgnore
    @JoinColumn(name = "modified_by")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private User modifiedBy;

    @JsonIgnore
    @Column(name = "disabled_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date disabledAt;

    @JsonIgnore
    @JoinColumn(name = "disabled_by")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;

}
