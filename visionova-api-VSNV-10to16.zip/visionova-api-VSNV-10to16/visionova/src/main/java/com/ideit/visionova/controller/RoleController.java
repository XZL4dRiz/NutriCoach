package com.ideit.visionova.controller;

import com.ideit.visionova.entities.Role;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.RoleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/roles")
@RequiredArgsConstructor
public class RoleController {

    private final RoleService roleService;

    // Crear un nuevo rol
    @PostMapping
    public ResponseEntity<Role> createRole(@RequestBody Role role, @RequestParam Long userId) {

        User user = new User();
        user.setId(userId);
        
        Role createdRole = roleService.createRole(role, user);
        return ResponseEntity.ok(createdRole);
    }

    // Modificar un rol existente
    @PutMapping("/{id}")
    public ResponseEntity<Role> modifyRole(@PathVariable Long id, @RequestBody Role role, @RequestParam Long userId) {
        
        role.setId(id);
        User user = new User();
        user.setId(userId);

        Role modifiedRole = roleService.modifyRole(role, user);
        if (modifiedRole != null) {
            return ResponseEntity.ok(modifiedRole);
        }
        return ResponseEntity.notFound().build();
    }

    // Deshabilitar un rol
    @PatchMapping("/{id}/disable")
    public ResponseEntity<Role> disableRole(@PathVariable Long id, @RequestParam Long userId) {
        User user = new User();
        user.setId(userId);
        Role role = new Role();
        role.setId(id);

        Role disableRole = roleService.disableRole(role, user);
        if (disableRole != null) {
            return ResponseEntity.ok(disableRole);
        }
        return ResponseEntity.notFound().build();
    }

    // Obtener un rol por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Role> getRoleById(@PathVariable Long id) {
        Optional<Role> role = roleService.findById(id);
        return role.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
