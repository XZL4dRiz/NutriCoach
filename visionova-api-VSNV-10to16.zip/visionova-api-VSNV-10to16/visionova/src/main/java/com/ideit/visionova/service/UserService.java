package com.ideit.visionova.service;

import java.util.Optional;

import com.ideit.visionova.entities.User;

public interface UserService {

    public User createUser(User user1, User user2);

    public User modifyUser(User user1, User user2);

    public User disableUser(User user1, User user2);

    public Optional<User> findById(Long id);

}