package com.ideit.visionova.service;

import java.util.Optional;

import com.ideit.visionova.entities.Role;
import com.ideit.visionova.entities.User;

public interface RoleService {

    public Role createRole(Role role, User user);

    public Role modifyRole(Role role, User user);

    public Role disableRole(Role role, User user);

    public Optional<Role> findById(Long id);
}