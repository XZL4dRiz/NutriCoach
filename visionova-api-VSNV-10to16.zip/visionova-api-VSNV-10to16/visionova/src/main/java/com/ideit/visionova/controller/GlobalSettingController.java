
package com.ideit.visionova.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ideit.visionova.Exception.ResourceNotFoundException;
import com.ideit.visionova.entities.GlobalSetting;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.GlobalSettingService;

@RestController
@RequestMapping(path = "/global-settings", produces = MediaType.APPLICATION_JSON_VALUE)
public class GlobalSettingController {

    @Autowired
    private GlobalSettingService globalSettingService;

    @GetMapping
    public ResponseEntity<List<GlobalSetting>> getAll() {
        List<GlobalSetting> result = globalSettingService.getAll();
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<GlobalSetting> getById(@PathVariable("id") Long id) {
        Optional<GlobalSetting> globalSetting = globalSettingService.findById(id);
        if (globalSetting.isEmpty()) {
            throw new ResourceNotFoundException("No existe el parámetro global con id " + id);
        }
        return new ResponseEntity<>(globalSetting.get(), HttpStatus.OK);
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @RequestMapping("/global-setting")
    public ResponseEntity<GlobalSetting> create(@RequestBody GlobalSetting globalSetting) throws Exception {
        // Obtener el usuario de la autenticación
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        // Verificar si el usuario está presente
        if (user == null) {
            throw new Exception("Usuario no autenticado");
        }

        // Crear el parámetro global
        GlobalSetting newGlobalSetting = globalSettingService.createGlobalSetting(globalSetting, user);
        
        // Retornar la respuesta sin la URI si no es necesaria
        return ResponseEntity.status(HttpStatus.CREATED).body(newGlobalSetting);
    }

    @PutMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GlobalSetting> update(@PathVariable("id") Long id, @RequestBody GlobalSetting globalSetting) throws Exception {
        Optional<GlobalSetting> optionalSetting = globalSettingService.findById(id);

        // Obtener el usuario de la autenticación
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        // Verificar si el usuario está presente
        if (user == null) {
            throw new Exception("Usuario no autenticado");
        }

        globalSetting.setId(id);
        if (optionalSetting.isEmpty()) {
            throw new ResourceNotFoundException("No existe el parámetro global con id " + id);
        }

        // Actualizar el parámetro global
        GlobalSetting updatedGlobalSetting = globalSettingService.editGlobalSetting(globalSetting, user);
        return new ResponseEntity<>(updatedGlobalSetting, HttpStatus.OK);
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<HttpStatus> delete(@PathVariable("id") Long id) {
        Optional<GlobalSetting> optionalGlobalSetting = globalSettingService.findById(id);

        // Obtener el usuario de la autenticación
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        // Verificar si el usuario está presente
        if (user == null) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        // Verificar si el parámetro global existe
        GlobalSetting globalSetting = optionalGlobalSetting.orElseThrow(() -> new ResourceNotFoundException("No se encontró el parámetro global con id " + id));

        // Deshabilitar el parámetro global
        globalSettingService.disableGlobalSetting(globalSetting, user);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
