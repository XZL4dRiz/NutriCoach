package com.ideit.visionova.entities;

import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "core_user")
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class User implements CrudEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @Getter
    @Setter
    private Long id;

    @Column(name = "login", nullable = false, unique = true)
    @Getter
    @Setter
    private String login;

    @Column(name = "password", nullable = false)
    @Getter
    @Setter
    private String password;

    @Column(name = "created_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "created_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User createdBy;

    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JoinColumn(name = "modified_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User modifiedBy;

    @Column(name = "disabled_at")
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    @Setter
    private Date disabledAt;

    @JoinColumn(name = "disabled_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;

    @ManyToMany(fetch = FetchType.EAGER)
    @Getter
    @Setter
    @JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new LinkedHashSet<>();
}