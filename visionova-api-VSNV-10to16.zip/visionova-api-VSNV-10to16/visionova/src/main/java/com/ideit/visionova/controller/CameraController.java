package com.ideit.visionova.controller;

import com.ideit.visionova.entities.Camera;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.CameraService;
import com.ideit.visionova.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/cameras")
@RequiredArgsConstructor
public class CameraController {

    private final CameraService cameraService;
    private final UserService userService; // Used to get the user performing the action

    //Create a new camera
    @PostMapping
    public ResponseEntity<Camera> createCamera(@RequestBody Camera camera, @RequestParam Long userId) {
        // Check if the user exists
        Optional<User> userOptional = userService.findById(userId);
        if (userOptional.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        Camera createdCamera = cameraService.createCamera(camera, userOptional.get());
        return ResponseEntity.ok(createdCamera);
    }

    // Modify an existing camera
    @PutMapping("/{id}")
    public ResponseEntity<Camera> modifyCamera(@PathVariable Long id, @RequestBody Camera camera, @RequestParam Long userId) {
        // Check if the user exists
        Optional<User> userOptional = userService.findById(userId);
        if (userOptional.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        camera.setId(id); // Set the camera ID for modification
        Camera modifiedCamera = cameraService.modifyCamera(camera, userOptional.get());
        if (modifiedCamera == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(modifiedCamera);
    }

    // Disable a camera
    @PatchMapping("/{id}/disable")
    public ResponseEntity<Camera> disableCamera(@PathVariable Long id, @RequestParam Long userId) {
        // Check if the user exists
        Optional<User> userOptional = userService.findById(userId);
        if (userOptional.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        Camera camera = new Camera();
        camera.setId(id);
        Camera disabledCamera = cameraService.disableCamera(camera, userOptional.get());
        if (disabledCamera == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(disabledCamera);
    }

    // Get a camera by its ID
    @GetMapping("/{id}")
    public ResponseEntity<Camera> getCameraById(@PathVariable Long id) {
        Optional<Camera> camera = cameraService.findById(id);
        return camera.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all cameras with pagination
    @GetMapping
    public ResponseEntity<Page<Camera>> getAllCameras(Pageable pageable) {
        Page<Camera> cameras = cameraService.findAll(pageable);
        return ResponseEntity.ok(cameras);
    }

}
