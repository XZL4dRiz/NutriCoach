package com.ideit.visionova.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.ideit.visionova.entities.User;



public interface UserPrincipalRepository extends CrudRepository<User, Long> {
	
	
	public Optional<User> findByLogin(String login);	//special method only used to load principal of JWT
	
	
	

}
