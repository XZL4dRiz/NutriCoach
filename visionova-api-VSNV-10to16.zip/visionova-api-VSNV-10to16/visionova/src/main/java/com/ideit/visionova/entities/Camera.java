package com.ideit.visionova.entities;

import java.util.Date;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "camera")
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class Camera implements CrudEntity{

    @Column(name = "id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    private Long id;

    @Getter
    @Setter
    @Column(name = "location", nullable = false)
    private String location;

    @Getter
    @Setter
    @Column(name = "type", nullable = false)
    private String type;

    @Getter
    @Setter
    @Column(name = "active")
    private Boolean active = true;

    @Getter
    @Setter
    @Lob
    @Column(name = "source", nullable = false)
    private String source;

    @Column(name = "created_at", nullable = false)
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "created_by", nullable = false)
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User createdBy;

    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JoinColumn(name = "modified_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User modifiedBy;

    @Column(name = "disabled_at")
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    @Setter
    private Date disabledAt;

    @JoinColumn(name = "disabled_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;

}