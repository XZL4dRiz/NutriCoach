package com.ideit.visionova.Exception;

public class CameraNotFoundException extends RuntimeException {

    // Constructor that accepts a message
    public CameraNotFoundException(String message) {
        super(message);
    }

    // Constructor that accepts a message and a cause
    public CameraNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}

