package com.ideit.visionova.repository;

import com.ideit.visionova.entities.AnalysisProcess;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Set;

public interface AnalysisProcessRepository extends CrudRepository<AnalysisProcess, Long>, PagingAndSortingRepository<AnalysisProcess, Long> {

    Page<AnalysisProcess> findByNameLikeAndEnabled(String name, Boolean enabled, Pageable pageable);

    Page<AnalysisProcess> findByDescriptionLikeAndEnabled(String description, Boolean enabled, Pageable pageable);

    Page<AnalysisProcess> findByEnabled(Boolean enabled, Pageable pageable);

    Page<AnalysisProcess> findByEnabledAndIdIn(Boolean enabled, Set<Long> ids, Pageable pageable);

    Iterable<AnalysisProcess> findByEnabled(Boolean enabled);

    Iterable<AnalysisProcess> findByNameLikeAndEnabled(String name, Boolean enabled); 
}
