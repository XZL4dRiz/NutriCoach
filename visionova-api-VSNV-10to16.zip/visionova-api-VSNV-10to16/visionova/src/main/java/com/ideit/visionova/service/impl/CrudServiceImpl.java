package com.ideit.visionova.service.impl;

import java.util.Date;

import com.ideit.visionova.entities.CrudEntity;
import com.ideit.visionova.entities.User;

public class CrudServiceImpl {
	
	protected void fillCreationData(CrudEntity crudEntity, User user) {
		crudEntity.setEnabled(true);
		crudEntity.setCreatedAt(new Date());
		crudEntity.setCreatedBy(user);
	}
	
	protected void fillModificationData(CrudEntity crudEntity, User user) {
		crudEntity.setModifiedAt(new Date());
		crudEntity.setModifiedBy(user);
	}
	
	protected void fillDisabilitationData(CrudEntity crudEntity, User user) {
		crudEntity.setEnabled(false);
		crudEntity.setDisabledAt(new Date());
		crudEntity.setDisabledBy(user);
	}
	
	protected void restoreCrudEntityDataWithCurrentEntity(CrudEntity current, CrudEntity newCrudEntity) {
		newCrudEntity.setEnabled(current.getEnabled());
		newCrudEntity.setCreatedAt(current.getCreatedAt());
		newCrudEntity.setCreatedBy(current.getCreatedBy());
		
		newCrudEntity.setModifiedAt(current.getModifiedAt());
		newCrudEntity.setModifiedBy(current.getModifiedBy());
		
		newCrudEntity.setDisabledAt(current.getDisabledAt());
		newCrudEntity.setDisabledBy(current.getDisabledBy());
	}

	protected String asLike (String name) {
		if (name!=null)
			name = name.replace('*', '%');
		return name;
	}

}
