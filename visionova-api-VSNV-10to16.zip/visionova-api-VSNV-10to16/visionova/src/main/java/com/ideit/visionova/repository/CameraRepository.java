package com.ideit.visionova.repository;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ideit.visionova.entities.Camera;

public interface CameraRepository extends CrudRepository<Camera, Long>, PagingAndSortingRepository<Camera, Long> {

    Page<Camera> findBySourceLikeAndEnabled(String source, Boolean enabled, Pageable pageable);

    Page<Camera> findByLocationAndEnabled(String location, Boolean enabled, Pageable pageable);

    Page<Camera> findByTypeAndEnabled(String type, Boolean enabled, Pageable pageable);

    Page<Camera> findByEnabled(Boolean enabled, Pageable pageable);

    Page<Camera> findByEnabledAndIdIn(Boolean enabled, Set<Long> ids, Pageable pageable);

    Iterable<Camera> findByEnabled(Boolean enabled);

    Iterable<Camera> findByLocationAndEnabled(String location, Boolean enabled);
}