package com.ideit.visionova.repository;

import com.ideit.visionova.entities.Role;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;
import java.util.Set;

public interface RoleRepository extends CrudRepository<Role, Long>, PagingAndSortingRepository<Role, Long> {

    Page<Role> findByNameLikeAndEnabled(String name, Boolean enabled, Pageable pageable);

    Page<Role> findByEnabled(Boolean enabled, Pageable pageable);

    Page<Role> findByEnabledAndIdIn(Boolean enabled, Set<Long> ids, Pageable pageable);

    Iterable<Role> findByEnabled(Boolean enabled);

    Iterable<Role> findByNameLikeAndEnabled(String name, Boolean enabled);

    Optional<Role> findByName(String name);

}
