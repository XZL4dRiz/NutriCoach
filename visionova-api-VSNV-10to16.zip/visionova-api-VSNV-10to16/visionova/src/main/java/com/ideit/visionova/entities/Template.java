package com.ideit.visionova.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table(name="template")
@ToString
@EqualsAndHashCode
@NoArgsConstructor

public class Template implements CrudEntity{
    @Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	@Getter
    @Setter 
	private Long id;

    @Column(name = "template_name", nullable = false, length = 50)
    @Getter
    @Setter
    private String templateName;

    @Column(name = "coordinates", columnDefinition = "TEXT")
    @Getter
    @Setter
    private String coordinates;

    @JsonIgnore
    @Column(name = "created_at", nullable = false)
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;


    @JsonIgnore
    @JoinColumn(name = "created_by")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private User createdBy;

    @JsonIgnore
    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JsonIgnore
    @JoinColumn(name = "modified_by")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private User modifiedBy;

    @JsonIgnore
    @Column(name = "disabled_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date disabledAt;

    @JsonIgnore
    @JoinColumn(name = "disabled_by")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;

}