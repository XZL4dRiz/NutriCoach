package com.ideit.visionova.service;

import com.ideit.visionova.entities.Camera;
import com.ideit.visionova.entities.User;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface CameraService {

    public Camera createCamera(Camera camera, User user);

    public Camera modifyCamera(Camera camera, User user);

    public Camera disableCamera(Camera camera, User user);

    public Optional<Camera> findById(Long id);

    public Page<Camera> findAll(Pageable pageable);

}
