package com.ideit.visionova.entities;

import java.util.Date;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "core_role")
@ToString
@EqualsAndHashCode
@NoArgsConstructor

public class Role implements CrudEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
	@Getter
	@Setter
    private Long id;

    @Column(name="name", nullable = false)
	@Getter
    @Setter
    private String name;

    @Column(name = "created_at", nullable = false)
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "created_by", nullable = false)
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User createdBy;

    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JoinColumn(name = "modified_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User modifiedBy;

    @Column(name = "disabled_at")
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    @Setter
    private Date disabledAt;

    @JoinColumn(name = "disabled_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;
}