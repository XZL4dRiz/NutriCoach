package com.ideit.visionova.repository;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import com.ideit.visionova.entities.*;;



public interface UserRepository extends CrudRepository<User, Long>, PagingAndSortingRepository<User, Long> {

    Page<User> findByLoginLikeAndEnabled(String login, Boolean enabled, Pageable pageable);

    Page<User> findByEnabled(Boolean enabled, Pageable pageable);

    Page<User> findByEnabledAndIdIn(Boolean enabled, Set<Long> ids, Pageable pageable);

    Iterable<User> findByEnabled(Boolean enabled);

    Iterable<User> findByLoginLikeAndEnabled(String login, Boolean enabled);

    Optional<User> findByLogin(String login);

    boolean existsByLogin(String loginString);


}