
package com.ideit.visionova.Jwt;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.ideit.visionova.Exception.RefreshTokenExpirationException;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@RestControllerAdvice
public class TokenControllerAdvice {

    private static final Logger log = LoggerFactory.getLogger(TokenControllerAdvice.class);

    @ExceptionHandler(value = RefreshTokenExpirationException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorMessage handleTokenRefreshException(RefreshTokenExpirationException ex, WebRequest request) {
        log.error("Refresh token expired: {}", ex.getMessage());
        return new ErrorMessage(
            HttpStatus.FORBIDDEN.value(),
            new Date(),
            ex.getMessage(),
            request.getDescription(false)
        );
    }

    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorMessage handleInvalidArgumentException(IllegalArgumentException ex, WebRequest request) {
        log.error("Invalid argument error: {}", ex.getMessage());
        return new ErrorMessage(
            HttpStatus.BAD_REQUEST.value(),
            new Date(),
            ex.getMessage(),
            request.getDescription(false)
        );
    }

    @ExceptionHandler(value = Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorMessage handleGeneralException(Exception ex, WebRequest request) {
        log.error("Internal server error: {}", ex.getMessage());
        return new ErrorMessage(
            HttpStatus.INTERNAL_SERVER_ERROR.value(),
            new Date(),
            ex.getMessage(),
            request.getDescription(false)
        );
    }
}
