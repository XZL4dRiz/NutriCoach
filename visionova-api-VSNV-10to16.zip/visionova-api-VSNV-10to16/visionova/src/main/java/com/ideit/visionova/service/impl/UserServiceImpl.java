
package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.UserRepository;
import com.ideit.visionova.service.UserService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl extends CrudServiceImpl implements UserService {

    @PersistenceContext
    private EntityManager entityManager;

    private final UserRepository userRepository;

    @Transactional
    @Override
    public User createUser(User user, User createdBy) {
        log.debug("createUser");
        createdBy = entityManager.find(User.class, createdBy.getId());
        fillCreationData(user, createdBy);
        checkInsertPreconditions(user);
        return userRepository.save(user);
    }

    @Transactional
    @Override
    public User modifyUser(User modifiedUser, User modifiedBy) {
    Optional<User> existingUserOpt = userRepository.findById(modifiedUser.getId());
    if (existingUserOpt.isPresent()) {
        User existingUser = existingUserOpt.get();
        existingUser.setLogin(modifiedUser.getLogin());
        existingUser.setPassword(modifiedUser.getPassword());
        // Aplica otros cambios necesarios a existingUser
        
        return userRepository.save(existingUser); // Asegúrate de que los cambios se persistan
    } else {
        throw new EntityNotFoundException("User not found");
    }
}


    @Transactional
    @Override
    public User disableUser(User user, User disabledBy) {
        log.debug("disableUser");
        Optional<User> findById = userRepository.findById(user.getId());
        if (findById.isPresent()) {
            User current = findById.get();
            disabledBy = entityManager.find(User.class, disabledBy.getId());
            fillDisabilitationData( current, disabledBy);
            return entityManager.merge(current);
        }
        return null;
    }

    public void checkInsertPreconditions(User user) {
        checkLoginPrecondition(user);
    }

    public void checkLoginPrecondition(User user) {
        userRepository.findByLoginLikeAndEnabled(user.getLogin(), true, Pageable.unpaged());
    }

    @Override
    public Optional<User> findById(Long id) {
        log.debug("findById");
        return userRepository.findById(id);
    }

    public void checkEditPreconditions(User user, User current) {
        if (!current.getLogin().equalsIgnoreCase(user.getLogin())) {
            checkLoginPrecondition(user);
        }
    }

    public void restoreCrudEntityDataWithCurrentEntity(User current, User user) {
        user.setLogin(current.getLogin());
        user.setPassword(current.getPassword());
    }
}
