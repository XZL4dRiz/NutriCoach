package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.Role;
import com.ideit.visionova.entities.User;

import com.ideit.visionova.service.RoleService;
import com.ideit.visionova.repository.RoleRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
@Slf4j
public class RoleServiceImpl extends CrudServiceImpl implements RoleService {

    @PersistenceContext
    private EntityManager entityManager;

    private RoleRepository roleRepository;

    public RoleServiceImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Transactional
    @Override
    public Role createRole(Role role, User user){
        log.debug("createRole");
        user = entityManager.find(User.class, user.getId());
        fillCreationData(role, user);
        checkInsertPreconditions(role);
        return roleRepository.save(role);
    }

    @Transactional
    @Override
    public Role modifyRole(Role role, User user){
        log.debug("modifyRole");
        Optional<Role> findById = roleRepository.findById(role.getId());
        if (findById.isPresent()) {
            Role current = findById.get();
            checkEditPreconditions(role, current);
            restoreCrudEntityDataWithCurrentEntity(current, role);
            user = entityManager.find(User.class, user.getId());
            fillModificationData(role, user);
            return entityManager.merge(role);
        }
        return null;
    }

    @Transactional
    @Override
    public Role disableRole(Role role, User user){
        log.debug("disableRole");
        Optional<Role> findById = roleRepository.findById(role.getId());
        if (findById.isPresent()) {
            Role current = findById.get();
            user = entityManager.find(User.class, user.getId());
            fillDisabilitationData(current, user);
            return entityManager.merge(current);
        }
        return null;
    }

    private void checkInsertPreconditions(Role role) {
        checkNamePrecondition(role);
    }

    private void checkNamePrecondition(Role role) {
        roleRepository.findByNameLikeAndEnabled(role.getName(), true, Pageable.unpaged());
    }

    @Override
    public Optional<Role> findById(Long id) {
        log.debug("findById");
        return roleRepository.findById(id);
    }

    private void checkEditPreconditions(Role role, Role current) {
        if (!current.getName().equalsIgnoreCase(role.getName())) {
            checkNamePrecondition(role);
        }
    }
}