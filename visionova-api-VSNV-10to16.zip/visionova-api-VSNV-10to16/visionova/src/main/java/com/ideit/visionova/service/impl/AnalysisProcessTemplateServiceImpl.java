package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.AnalysisProcessTemplate;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.AnalysisProcessTemplateRepository;
import com.ideit.visionova.service.AnalysisProcessTemplateService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class AnalysisProcessTemplateServiceImpl extends CrudServiceImpl implements AnalysisProcessTemplateService {

    @PersistenceContext
    private EntityManager entityManager;

    private final AnalysisProcessTemplateRepository analysisProcessTemplateRepository;

    @Transactional
    @Override
    public AnalysisProcessTemplate createAnalysisProcessTemplate(AnalysisProcessTemplate analysisProcessTemplate, User user) {
        log.debug("createAnalysisProcessTemplate");
        user = entityManager.find(User.class, user.getId());
        fillCreationData(analysisProcessTemplate, user);
        checkInsertPreconditions(analysisProcessTemplate);
        return analysisProcessTemplateRepository.save(analysisProcessTemplate);
    }

    @Transactional
    @Override
    public AnalysisProcessTemplate modifyAnalysisProcessTemplates(AnalysisProcessTemplate analysisProcessTemplate, User user) {
        log.debug("modifyAnalysisProcessTemplate");
        Optional<AnalysisProcessTemplate> findById = analysisProcessTemplateRepository.findById(analysisProcessTemplate.getId());
        if (findById.isPresent()) {
            AnalysisProcessTemplate current = findById.get();
            checkEditPreconditions(analysisProcessTemplate, current);
            restoreCrudEntityDataWithCurrentEntity(current, analysisProcessTemplate);
            user = entityManager.find(User.class, user.getId());
            fillModificationData(analysisProcessTemplate, user);
            return entityManager.merge(analysisProcessTemplate);
        }
        return null;
    }

    @Transactional
    @Override
    public AnalysisProcessTemplate disableAnalysisProcessTemplate(AnalysisProcessTemplate analysisProcessTemplate, User user) {
        log.debug("disableAnalysisProcessTemplate");
        Optional<AnalysisProcessTemplate> findById = analysisProcessTemplateRepository.findById(analysisProcessTemplate.getId());
        if (findById.isPresent()) {
            AnalysisProcessTemplate current = findById.get();
            user = entityManager.find(User.class, user.getId());
            fillDisabilitationData(current, user);
            return entityManager.merge(current);
        }
        return null;
    }

    private void checkInsertPreconditions(AnalysisProcessTemplate analysisProcessTemplate) {
        checkTemplatePrecondition(analysisProcessTemplate);
    }

    private void checkTemplatePrecondition(AnalysisProcessTemplate analysisProcessTemplate) {
        analysisProcessTemplateRepository.findByParametersLikeAndEnabled(analysisProcessTemplate.getParameters(), true, Pageable.unpaged());
    }

    @Override
    public Optional<AnalysisProcessTemplate> findById(Long id) {
        log.debug("findById");
        return analysisProcessTemplateRepository.findById(id);
    }

    private void checkEditPreconditions(AnalysisProcessTemplate analysisProcessTemplate, AnalysisProcessTemplate current) {
        if (!current.getParameters().equalsIgnoreCase(analysisProcessTemplate.getParameters())) {
            checkTemplatePrecondition(analysisProcessTemplate);
        }
    }

    @Override
    public Iterable<AnalysisProcessTemplate> findByEnabled(Boolean enabled) {
        log.debug("findByEnabled");
        return analysisProcessTemplateRepository.findByEnabled(enabled);
    }

    private void restoreCrudEntityDataWithCurrentEntity(AnalysisProcessTemplate current, AnalysisProcessTemplate newEntity) {
        // Restaurar atributos CRUD de la entidad, si fuera necesario.
    }
}