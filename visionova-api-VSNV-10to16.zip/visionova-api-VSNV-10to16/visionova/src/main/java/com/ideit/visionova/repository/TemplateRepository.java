package com.ideit.visionova.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ideit.visionova.entities.Template;

public interface TemplateRepository extends CrudRepository<Template, Long>, PagingAndSortingRepository<Template, Long>{


    // Método para encontrar plantillas por nombre (similar) que estén habilitadas
    Page<Template> findByTemplateNameLikeAndEnabled(String templateName, boolean enabled, Pageable pageable);


    // Método para buscar todas las plantillas habilitadas con paginación
    Page<Template> findByEnabled(boolean enabled, Pageable pageable);

    // Puedes agregar otros métodos personalizados según sea necesario, como búsqueda por otros campos

}
