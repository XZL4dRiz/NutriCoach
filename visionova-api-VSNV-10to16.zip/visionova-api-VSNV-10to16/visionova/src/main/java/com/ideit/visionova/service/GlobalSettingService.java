package com.ideit.visionova.service;

import java.util.List;
import java.util.Optional;

import com.ideit.visionova.Exception.UniqueFieldAlreadyExistsException;
import com.ideit.visionova.entities.GlobalSetting;
import com.ideit.visionova.entities.User;

public interface GlobalSettingService {


    /**
    * Recupera todos los parámetros globales.
    * 
    * @return Lista de parámetros globales.
    */
    List<GlobalSetting> getAll();


    /**
     * Crea un nuevo parámetro global.
     * 
     * @param globalSetting Parámetro global a crear.
     * @param user Usuario que está creando el parámetro.
     * @return El parámetro global creado.
     * @throws UniqueFieldAlreadyExistsException Si el nombre del parámetro ya existe.
     */
    GlobalSetting createGlobalSetting(GlobalSetting globalSetting, User user) throws Exception;

    /**
     * Edita un parámetro global existente.
     * 
     * @param globalSetting Parámetro global a editar.
     * @param user Usuario que está editando el parámetro.
     * @return El parámetro global editado.
     * @throws UniqueFieldAlreadyExistsException Si el nombre del parámetro ya existe.
     */
    GlobalSetting editGlobalSetting(GlobalSetting globalSetting, User user) throws Exception;

    /**
     * Deshabilita un parámetro global.
     * 
     * @param globalSetting Parámetro global a deshabilitar.
     * @param user Usuario que está deshabilitando el parámetro.
     * @return El parámetro global deshabilitado.
     */
    GlobalSetting disableGlobalSetting(GlobalSetting globalSetting, User user);

   

    /**
     * Busca un parámetro global por su ID.
     * 
     * @param id El ID del parámetro global a buscar.
     * @return El parámetro global con el ID proporcionado.
     */
    Optional<GlobalSetting> findById(Long id);


}
