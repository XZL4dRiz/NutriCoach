package com.ideit.visionova.entities;


import java.util.Date;

public interface CrudEntity {

	
	public void setEnabled(Boolean enabled);
	public Boolean getEnabled();
	
	
	public void setCreatedAt(Date createdAt);
	public Date getCreatedAt();
	public void setCreatedBy(User user);
	public User getCreatedBy();
	
	public void setModifiedAt(Date modifiedAt);
	public Date getModifiedAt();
	public void setModifiedBy(User user);
	public User getModifiedBy();
	
	public void setDisabledAt(Date disabledAt);
	public Date getDisabledAt();
	public void setDisabledBy(User user);
	public User getDisabledBy();
	
	
}
