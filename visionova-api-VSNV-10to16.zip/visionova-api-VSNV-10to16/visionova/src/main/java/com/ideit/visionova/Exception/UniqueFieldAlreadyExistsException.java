package com.ideit.visionova.Exception;


    public class UniqueFieldAlreadyExistsException extends RuntimeException {

        public UniqueFieldAlreadyExistsException() {
            super();
        }
    
        public UniqueFieldAlreadyExistsException(String message) {
            super(message);
        }
    
        public UniqueFieldAlreadyExistsException(String message, Throwable cause) {
            super(message, cause);
        }
    
        public UniqueFieldAlreadyExistsException(Throwable cause) {
            super(cause);
        }
    }
    

