package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.User;
import com.ideit.visionova.Jwt.*;
import com.ideit.visionova.entities.Role;
import com.ideit.visionova.repository.UserRepository;
import com.ideit.visionova.repository.RoleRepository;
import com.ideit.visionova.service.AuthenticationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtTokenUtil;

    @Autowired
    public AuthenticationServiceImpl(UserRepository userRepository, RoleRepository roleRepository, 
                                     PasswordEncoder passwordEncoder, JwtUtils jwtTokenUtil) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenUtil = jwtTokenUtil;
    }

    @Override
    public Optional<User> authenticate(String username, String password) {
        Optional<User> userOpt = userRepository.findByLogin(username);
        if (userOpt.isPresent() && passwordEncoder.matches(password, userOpt.get().getPassword())) {
            return userOpt;
        }
        return Optional.empty();
    }

    @Override
    public User getUserFromToken(String token) {
        String username = jwtTokenUtil.getUserNameFromJwtToken(token);
        return userRepository.findByLogin(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }

    @Override
    public User registerUser(User user) {
        if (user.getRoles() == null || user.getRoles().isEmpty()) {
            Role defaultRole = roleRepository.findByName("ROLE_USER")
                    .orElseThrow(() -> new RuntimeException("Default role not found"));
            user.setRoles(Collections.singleton(defaultRole));
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    @Override
    public boolean isUsernameTaken(String username) {
        return userRepository.existsByLogin(username);
    }

    @Override
    public Optional<User> findUserByLogin(String username) {
        return userRepository.findByLogin(username);
    }

    @Override
    public String generateJwtToken(User user) {
        return jwtTokenUtil.generateTokenFromUsername(user.getLogin());
    }
}
