package com.ideit.visionova.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.ideit.visionova.Exception.ResourceNotFoundException;
import com.ideit.visionova.entities.Template;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.TemplateService;

@RestController
@RequestMapping(path = "/templates", produces = MediaType.APPLICATION_JSON_VALUE)
public class TemplateController{

    @Autowired
    private TemplateService templateService;

    // Obtener todos los templates
    @GetMapping
    public ResponseEntity<List<Template>> getAll() {
        List<Template> result = templateService.getAll();
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    // Obtener un template por ID
    @GetMapping(path = "/{id}")
    public ResponseEntity<Template> getById(@PathVariable("id") Long id) {
        Optional<Template> template = templateService.findById(id);
        if (template.isEmpty()) {
            throw new ResourceNotFoundException("No existe el template con id " + id);
        }
        return new ResponseEntity<>(template.get(), HttpStatus.OK);
    }

    // Crear un nuevo template
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Template> create(@RequestBody Template template) {
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal(); 
        Template newTemplate = templateService.createTemplate(template, user);
        URI uri = createTemplateUri(newTemplate);
        return ResponseEntity.created(uri).body(newTemplate);
    }

    // Actualizar un template existente
    @PutMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Template> edit(@PathVariable("id") Long id, @RequestBody Template template) {
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        Optional<Template> optionalTemplate = templateService.findById(id);
        if (optionalTemplate.isEmpty()) {
            throw new ResourceNotFoundException("No existe el template con id " + id);
        }
        template.setId(id);
        Template updatedTemplate = templateService.editTemplate(template, user);
        return new ResponseEntity<>(updatedTemplate, HttpStatus.OK);
    }

    // Eliminar un template por ID (marcar como deshabilitado)
    @DeleteMapping(path = "/{id}")
    public ResponseEntity<HttpStatus> delete(@PathVariable("id") Long id) {
        Optional<Template> template = templateService.findById(id);
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        if (template.isEmpty()) {
            throw new ResourceNotFoundException("No existe el template con id " + id);
        }
        templateService.disableTemplate(template.get(), user);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Método auxiliar para crear la URI del template recién creado
    private URI createTemplateUri(Template template) {
        return ServletUriComponentsBuilder.fromCurrentRequestUri().path("/{id}")
                .buildAndExpand(template.getId()).toUri();
    }
}


