package com.ideit.visionova.service;

import com.ideit.visionova.entities.AnalysisProcess;
import com.ideit.visionova.entities.User;


import java.util.Optional;

public interface AnalysisProcessService {

    public AnalysisProcess createAnalysisProcess(AnalysisProcess analysisProcess, User user);

    public AnalysisProcess modifyAnalysisProcess(AnalysisProcess analysisProcess, User user);

    public AnalysisProcess disableAnalysisProcess(AnalysisProcess analysisProcess, User user);

    public Optional<AnalysisProcess> findById(Long id);

    public Iterable<AnalysisProcess> findByEnabled(Boolean enabled);
}
