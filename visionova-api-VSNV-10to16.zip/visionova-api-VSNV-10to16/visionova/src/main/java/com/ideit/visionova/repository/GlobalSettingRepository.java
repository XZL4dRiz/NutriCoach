package com.ideit.visionova.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ideit.visionova.entities.GlobalSetting;

@Repository
public interface GlobalSettingRepository extends CrudRepository<GlobalSetting, Long> {

    // Verificar si un parámetro global con el nombre dado ya existe
    boolean existsByName(String name);

    // Buscar parámetros globales por nombre (con soporte de paginación)
    @Query("SELECT g FROM GlobalSetting g WHERE g.name LIKE %?1%")
    Page<GlobalSetting> findByNameContaining(String name, Pageable pageable);
    
    // Buscar parámetro global por nombre
    Optional<GlobalSetting> findByName(String name);
}

