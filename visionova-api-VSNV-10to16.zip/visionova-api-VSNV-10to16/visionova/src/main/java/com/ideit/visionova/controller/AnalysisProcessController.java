package com.ideit.visionova.controller;

import com.ideit.visionova.entities.AnalysisProcess;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.AnalysisProcessService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/analysis-processes")
@RequiredArgsConstructor
public class AnalysisProcessController {

    private final AnalysisProcessService analysisProcessService;

    // Create Analysis Process
    @PostMapping
    public ResponseEntity<AnalysisProcess> createAnalysisProcess(@RequestBody AnalysisProcess analysisProcess,
                                                                @RequestParam Long userId) {
        User user = new User();  // Assuming you retrieve the User by ID from your user service or repository
        user.setId(userId);
        AnalysisProcess createdAnalysisProcess = analysisProcessService.createAnalysisProcess(analysisProcess, user);
        return new ResponseEntity<>(createdAnalysisProcess, HttpStatus.CREATED);
    }

    // Modify Analysis Process
    @PutMapping("/{id}")
    public ResponseEntity<AnalysisProcess> modifyAnalysisProcess(@PathVariable Long id, 
                                                                @RequestBody AnalysisProcess analysisProcess,
                                                                @RequestParam Long userId) {
        User user = new User();  // Assuming you retrieve the User by ID
        user.setId(userId);
        analysisProcess.setId(id); // Ensure we're updating the correct entity
        AnalysisProcess updatedAnalysisProcess = analysisProcessService.modifyAnalysisProcess(analysisProcess, user);
        return updatedAnalysisProcess != null 
            ? new ResponseEntity<>(updatedAnalysisProcess, HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Disable Analysis Process
    @PatchMapping("/{id}/disable")
    public ResponseEntity<AnalysisProcess> disableAnalysisProcess(@PathVariable Long id, @RequestParam Long userId) {
        User user = new User();  // Assuming you retrieve the User by ID
        user.setId(userId);
        Optional<AnalysisProcess> disabledAnalysisProcess = analysisProcessService.findById(id)
                .map(analysisProcess -> analysisProcessService.disableAnalysisProcess(analysisProcess, user));
        return disabledAnalysisProcess.isPresent() 
            ? new ResponseEntity<>(disabledAnalysisProcess.get(), HttpStatus.OK)
            : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Get Analysis Process by ID
    @GetMapping("/{id}")
    public ResponseEntity<AnalysisProcess> getAnalysisProcess(@PathVariable Long id) {
        Optional<AnalysisProcess> analysisProcess = analysisProcessService.findById(id);
        return analysisProcess.map(process -> new ResponseEntity<>(process, HttpStatus.OK)).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Get all enabled Analysis Processes (can be expanded for pagination)
    @GetMapping
    public ResponseEntity<Iterable<AnalysisProcess>> getAllAnalysisProcesses() {
        Iterable<AnalysisProcess> processes = analysisProcessService.findByEnabled(true);
        return new ResponseEntity<>(processes, HttpStatus.OK);
    }
}