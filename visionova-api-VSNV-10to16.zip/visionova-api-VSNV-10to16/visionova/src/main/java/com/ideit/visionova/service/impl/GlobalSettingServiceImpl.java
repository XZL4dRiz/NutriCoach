package com.ideit.visionova.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.ideit.visionova.entities.GlobalSetting;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.GlobalSettingRepository;
import com.ideit.visionova.service.GlobalSettingService;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class GlobalSettingServiceImpl extends CrudServiceImpl implements GlobalSettingService {
    public EntityManager entityManager;

    private final GlobalSettingRepository globalSettingRepository;


    public List<GlobalSetting> getAll() {
        List<GlobalSetting> settings = new ArrayList<>();
        globalSettingRepository.findAll().forEach(settings::add);  // Convertimos a lista
        return settings.stream()
            .filter(GlobalSetting::getEnabled)  // Ajusta según tu campo `enabled`
            .collect(Collectors.toList());
    }

    @Transactional
    @Override
    public GlobalSetting createGlobalSetting(GlobalSetting globalSetting, User user) throws Exception {
        log.debug("createGlobalSetting");
        // Verificar que no exista un parámetro con el mismo nombre
        if (globalSettingRepository.existsByName(globalSetting.getName())) {
            throw new Exception("name");
        }

        // Asignar datos de creación (por ejemplo, creador y fecha de creación)
        globalSetting.setCreatedAt(new java.util.Date());
        globalSetting.setCreatedBy(user);
        return globalSettingRepository.save(globalSetting);
    }

    @Transactional
    @Override
    public GlobalSetting editGlobalSetting(GlobalSetting globalSetting, User user) throws Exception {
        log.debug("editGlobalSetting");

        // Verificar si existe el parámetro global
        Optional<GlobalSetting> existingSetting = globalSettingRepository.findById(globalSetting.getId());
        if (existingSetting.isPresent()) {
            // Verificar si el nombre del parámetro ha cambiado
            if (!existingSetting.get().getName().equals(globalSetting.getName()) &&
                    globalSettingRepository.existsByName(globalSetting.getName())) {
                throw new Exception("name");
            }

            // Asignar datos de modificación (por ejemplo, quién modificó y fecha de modificación)
            globalSetting.setModifiedAt(new java.util.Date());
            globalSetting.setModifiedBy(user);
            return globalSettingRepository.save(globalSetting);
        }

        return null;  // Retornar null si no se encontró el parámetro a modificar
    }

    @Transactional
    
    public GlobalSetting disableGlobalSetting(Long id, User user) {
        log.debug("disableGlobalSetting");

        Optional<GlobalSetting> existingSetting = globalSettingRepository.findById(id);
        if (existingSetting.isPresent()) {
            GlobalSetting globalSetting = existingSetting.get();
            globalSetting.setDisabledAt(new java.util.Date());
            globalSetting.setDisabledBy(user);
            return globalSettingRepository.save(globalSetting);
        }

        return null;  // Retornar null si no se encuentra el parámetro a deshabilitar
    }

    

    @Override
    public Optional<GlobalSetting> findById(Long id) {
        log.debug("findById");
        return globalSettingRepository.findById(id);
    }

   
    public Optional<GlobalSetting> findByName(String name) {
        log.debug("findByName");
        return globalSettingRepository.findByName(name);
    }

    @Override
    public GlobalSetting disableGlobalSetting(GlobalSetting globalSetting, User user) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
