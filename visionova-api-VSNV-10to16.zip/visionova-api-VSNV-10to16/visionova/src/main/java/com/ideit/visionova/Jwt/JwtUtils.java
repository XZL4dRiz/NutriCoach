package com.ideit.visionova.Jwt;

import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Component;
import org.springframework.web.util.WebUtils;

import com.ideit.visionova.entities.RefreshToken;
import com.ideit.visionova.security.service.UserDetailsImpl;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@SuppressWarnings("null")
public class JwtUtils {

    @Value("${visionova.app.jwtSecret}")
    private String jwtSecret;

    @Value("${visionova.app.jwtExpirationMs}")
    private int jwtExpirationMs;

    @Value("${visionova.app.jwtRefreshExpirationMs}")
    private int jwtRefreshTokenExpirationMs;

    @Value("${visionova.app.jwtCookieName}")
    private String jwtCookie;

    @Value("${visionova.app.jwtRefreshTokenCookieName}")
    private String jwtRefreshTokenCookie;

    public String getJwtFromCookies(HttpServletRequest request) {
        try {
            Cookie cookie = WebUtils.getCookie(request, jwtCookie);
            if (cookie != null) {
                log.debug("JWT cookie found");
                return cookie.getValue();
            } else {
                log.warn("JWT Cookie is missing");
                return null;
            }
        } catch (Exception e) {
            log.error("Error retrieving JWT from cookies: {}", e.getMessage(), e);
            throw new RuntimeException("Error retrieving JWT from cookies", e);
        }
    }

    public String getJwtRefereshTokenFromCookies(HttpServletRequest request) {
        Cookie cookie = WebUtils.getCookie(request, jwtRefreshTokenCookie);
        if (cookie != null) {
            log.debug("Refresh Token Cookie is not null");
            return cookie.getValue();
        } else {
            log.warn("Refresh Token Cookie is null");
            throw new IllegalArgumentException("Refresh Token cookie is missing");
        }
    }

    public ResponseCookie generateRefreshTokenCookie(RefreshToken refreshToken) {
        return ResponseCookie.from(jwtRefreshTokenCookie, refreshToken.getToken())
                .path("/api")
                .maxAge(jwtRefreshTokenExpirationMs / 1000)
                .httpOnly(true)
                .secure(true)
                .sameSite("Strict")
                .build();
    }

    public ResponseCookie generateJwtCookie(UserDetailsImpl userPrincipal) {
        return generateJwtCookie(userPrincipal.getUsername());
    }

    public ResponseCookie generateJwtCookie(String login) {
        try {
            String jwt = generateTokenFromUsername(login);
            if (jwt == null) {
                log.error("Failed to generate JWT token for user: {}", login);
                throw new RuntimeException("Failed to generate JWT token");
            }
            return ResponseCookie.from("jwt", jwt)
                    .path("/api")
                    .maxAge(jwtExpirationMs / 1000)
                    .httpOnly(true)
                    .secure(true)
                    .sameSite("Strict")
                    .build();
        } catch (Exception e) {
            log.error("Error generating JWT cookie for user {}: {}", login, e.getMessage(), e);
            throw new RuntimeException("Failed to generate JWT cookie", e);
        }
    }

    public ResponseCookie getCleanJwtCookie() {
        return ResponseCookie.from(jwtCookie, null)
                .path("/api")
                .httpOnly(true)
                .secure(true)
                .sameSite("Strict")
                .maxAge(0)
                .build();
    }

    public ResponseCookie getCleanJwtRefreshTokenCookie() {
        return ResponseCookie.from(jwtRefreshTokenCookie, null)
                .path("/api")
                .httpOnly(true)
                .secure(true)
                .sameSite("Strict")
                .maxAge(0)
                .build();
    }

    public String getUserNameFromJwtToken(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(jwtSecret.getBytes())
                    .build()
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();
        } catch (Exception e) {
            log.error("Failed to parse JWT token: {}", e.getMessage());
            throw new IllegalArgumentException("Failed to parse JWT token", e);
        }
    }

    @SuppressWarnings("deprecation")
    public boolean validateJwtToken(String authToken) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(jwtSecret.getBytes())
                    .build()
                    .parseClaimsJws(authToken);
            return true;
        } catch (SignatureException | MalformedJwtException | ExpiredJwtException | UnsupportedJwtException
                | IllegalArgumentException e) {
            log.error("JWT validation error: {}", e.getMessage());
        }
        return false;
    }

    public String generateTokenFromUsername(String username) {
        try {
            SecretKey hmacShaKeyFor = Keys.hmacShaKeyFor(jwtSecret.getBytes());
            return Jwts.builder()
                    .setSubject(username)
                    .setIssuedAt(new Date())
                    .setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
                    .signWith(hmacShaKeyFor, SignatureAlgorithm.HS512)
                    .compact();
        } catch (Exception e) {
            log.error("Error generating token for username: {}", username);
            throw new RuntimeException("Error generating token", e);
        }
    }
}
