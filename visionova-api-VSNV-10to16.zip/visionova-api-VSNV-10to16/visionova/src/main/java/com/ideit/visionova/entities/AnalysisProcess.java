package com.ideit.visionova.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "analysis_process")
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class AnalysisProcess implements CrudEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    @Column(name = "id")
    private Long id;

    @Getter
    @Setter
    @Column(name = "name", nullable = false)
    private String name;

    @Getter
    @Setter
    @Column(name = "description", nullable = false)
    private String description;

    @JsonIgnore
    @JoinColumn(name = "camera_id")
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    @Getter
    @Setter
    private Camera camera;

    @Transient
    private Long cameraId;

    @JsonProperty("cameraId")
    public void setCameraId(Long cameraId){
        this.cameraId = cameraId;
    }

    @JsonProperty("cameraId")
    public Long getCameraId(){
        if (cameraId!=null) 
            return cameraId;
        if (camera!=null)
            return camera.getId();
        else return null;
    }

    @Column(name = "created_at", nullable = false)
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @JoinColumn(name = "created_by", nullable = false)
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User createdBy;

    @Column(name = "modified_at")
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt;

    @JoinColumn(name = "modified_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User modifiedBy;

    @Column(name = "disabled_at")
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    @Setter
    private Date disabledAt;

    @JoinColumn(name = "disabled_by")
    @Getter
    @Setter
    @ManyToOne(optional = true, fetch = FetchType.LAZY)
    private User disabledBy;

    @Column(name = "enabled")
    @Getter
    @Setter
    private Boolean enabled = true;
}
