package com.ideit.visionova.service;

import java.util.Optional;

import com.ideit.visionova.entities.User;

public interface AuthenticationService {

    Optional<User> authenticate(String username, String password);

    User registerUser(User user);
    User getUserFromToken(String token);
    public boolean isUsernameTaken(String username);
    public Optional<User> findUserByLogin(String username);
    public String generateJwtToken(User user);
    
}
