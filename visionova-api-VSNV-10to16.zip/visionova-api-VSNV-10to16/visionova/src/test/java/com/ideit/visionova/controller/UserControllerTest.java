package com.ideit.visionova.controller;

import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class UserControllerTest {

    private MockMvc mockMvc;

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

        // Simular un usuario autenticado de la clase User
        User user = new User();
        user.setId(1L);
        user.setLogin("testUser");
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(user, null);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    public void testCreateUser() throws Exception {
        User user = new User();
        user.setLogin("newUser");
        user.setPassword("newPassword");

        User createdBy = new User();
        createdBy.setId(1L);

        given(userService.createUser(any(User.class), any(User.class))).willReturn(user);

        mockMvc.perform(post("/api/users")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{ \"login\": \"newUser\", \"password\": \"newPassword\" }")
            .param("createdById", "1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.login").value(user.getLogin()))
            .andExpect(jsonPath("$.password").value(user.getPassword()));
    }


    @Test
    public void testModifyUser() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setLogin("updatedUser");
        user.setPassword("updatedPassword");

        User modifiedBy = new User();
        modifiedBy.setId(1L);

        given(userService.modifyUser(any(User.class), any(User.class))).willReturn(user);

        mockMvc.perform(put("/api/users/{id}", user.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"login\": \"updatedUser\", \"password\": \"updatedPassword\" }")
                .param("modifiedById", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.login").value(user.getLogin()))
                .andExpect(jsonPath("$.password").value(user.getPassword()));
    }

    @Test
    public void testDisableUser() throws Exception {        
        User user = new User();
        user.setId(1L);
        user.setLogin("disabledUser");

        User disabledBy = new User();
        disabledBy.setId(1L);

        given(userService.disableUser(any(User.class), any(User.class))).willReturn(user);

        mockMvc.perform(patch("/api/users/{id}/disable", user.getId())
            .param("disabledById", "1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.login").value(user.getLogin()));
    }

}
