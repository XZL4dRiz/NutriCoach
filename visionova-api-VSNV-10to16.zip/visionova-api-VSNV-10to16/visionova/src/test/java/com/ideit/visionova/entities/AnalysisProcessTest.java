package com.ideit.visionova.entities;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AnalysisProcessTest {

    @Mock
    private Camera mockCamera;

    @Mock
    private User mockUser;

    private AnalysisProcess analysisProcess;

    @BeforeEach
    public void setUp() {
        analysisProcess = new AnalysisProcess();
    }

    @Test
    void testSetAndGetName() {
        analysisProcess.setName("Object Detection");
        assertEquals("Object Detection", analysisProcess.getName());
    }

    @Test
    void testSetAndGetDescription() {
        analysisProcess.setDescription("Detecting objects in the frame");
        assertEquals("Detecting objects in the frame", analysisProcess.getDescription());
    }

    @Test
    void testSetAndGetCamera() {
        analysisProcess.setCamera(mockCamera);
        assertEquals(mockCamera, analysisProcess.getCamera());
    }

    @Test
    void testSetAndGetCameraId() {
        analysisProcess.setCamera(mockCamera);
        when(mockCamera.getId()).thenReturn(10L);

        assertEquals(10L, analysisProcess.getCameraId());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date now = new Date();
        analysisProcess.setCreatedAt(now);
        assertEquals(now, analysisProcess.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        analysisProcess.setCreatedBy(mockUser);
        assertEquals(mockUser, analysisProcess.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date now = new Date();
        analysisProcess.setModifiedAt(now);
        assertEquals(now, analysisProcess.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        analysisProcess.setModifiedBy(mockUser);
        assertEquals(mockUser, analysisProcess.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date now = new Date();
        analysisProcess.setDisabledAt(now);
        assertEquals(now, analysisProcess.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        analysisProcess.setDisabledBy(mockUser);
        assertEquals(mockUser, analysisProcess.getDisabledBy());
    }

    @Test
    void testSetAndGetEnabled() {
        analysisProcess.setEnabled(false);
        assertFalse(analysisProcess.getEnabled());
    }

    @Test
    void testToString() {
        analysisProcess.setName("Object Detection");

        assertTrue(analysisProcess.toString().contains("Object Detection"));
    }

    @Test
    void testEqualsAndHashCode() {
        AnalysisProcess anotherProcess = new AnalysisProcess();
        anotherProcess.setName("Object Detection");

        analysisProcess.setName("Object Detection");

        assertEquals(analysisProcess, anotherProcess);
        assertEquals(analysisProcess.hashCode(), anotherProcess.hashCode());
    }
}
