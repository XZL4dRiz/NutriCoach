package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.Template;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.TemplateRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Collections;


import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class TemplateServiceImplTest {

    @InjectMocks
    private TemplateServiceImpl templateService;

    @Mock
    private TemplateRepository templateRepository;

    @Mock
    private EntityManager entityManager;

    @Mock
    private User user;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllTemplates_Success() {
        // Arrange
        Template template1 = new Template();
        template1.setId(1L);
        template1.setDisabledAt(null); // Enabled template

        Template template2 = new Template();
        template2.setId(2L);
        template2.setDisabledAt(null); // Enabled template

        when(templateRepository.findAll()).thenReturn(List.of(template1, template2));

        // Act
        List<Template> templates = templateService.getAll();

        // Assert
        assertNotNull(templates);
        assertEquals(2, templates.size());
        assertNull(templates.get(0).getDisabledAt()); // Assert it's enabled
        verify(templateRepository, times(1)).findAll();
    }

    @Test
    public void testCreateTemplate_Success() {
        // Arrange
        Template template = new Template();
        template.setTemplateName("New Template");
        template.setEnabled(true);

        when(entityManager.find(User.class, user.getId())).thenReturn(user);
        when(templateRepository.save(template)).thenReturn(template);
        when(templateRepository.findByTemplateNameLikeAndEnabled(template.getTemplateName(), true, Pageable.unpaged()))
                .thenReturn(null); // Name doesn't exist

        // Act
        Template savedTemplate = templateService.createTemplate(template, user);

        // Assert
        assertNotNull(savedTemplate);
        assertEquals(template.getTemplateName(), savedTemplate.getTemplateName());
        verify(entityManager, times(1)).find(User.class, user.getId());
        verify(templateRepository, times(1)).save(template);
    }

    @Test
    public void testCreateTemplate_NameAlreadyExists() {
        // Arrange
        Template template = new Template();
        template.setTemplateName("Existing Template");
        template.setEnabled(true);

        // Mock setup for findByTemplateNameLikeAndEnabled
        Page<Template> page = new PageImpl<>(Collections.singletonList(template)); // Create a page containing the
                                                                                   // template
        when(templateRepository.findByTemplateNameLikeAndEnabled(template.getTemplateName(), true, Pageable.unpaged()))
                .thenReturn(page); // Return the page

        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            templateService.createTemplate(template, user);
        });

        // Verify that the exception message is as expected
        assertEquals("Template with the same name already exists.", exception.getMessage());

        verify(templateRepository, times(1)).findByTemplateNameLikeAndEnabled(template.getTemplateName(), true,
                Pageable.unpaged());
    }

    @Test
    void testEditTemplate_Success() {
        // Configura tu Template de prueba y el usuario que está editando
        Template template = new Template();
        template.setId(1L); // Asegúrate de que el ID sea correcto
        template.setTemplateName("New Template Name");

        User user = new User();
        user.setId(1L); // Configura el ID del usuario para el mock

        // Configura el mock del repositorio para devolver el template adecuado
        when(templateRepository.findById(1L)).thenReturn(Optional.of(template)); // Mock para devolver el template con
                                                                                 // ID 1L
        when(templateRepository.save(any(Template.class))).thenReturn(template); // Mock para guardar el template

        // Llama al método que estás probando
        Template updatedTemplate = templateService.editTemplate(template, user);

        // Verifica que el resultado no sea nulo
        assertNotNull(updatedTemplate, "Template should not be null");

        // Verifica que el nombre del template se haya actualizado correctamente
        assertEquals("New Template Name", updatedTemplate.getTemplateName(), "Template name should be updated");
    }

    @Test
    public void testEditTemplate_RoleNotFound() {
        // Arrange
        Template template = new Template();
        template.setId(1L);

        when(templateRepository.findById(template.getId())).thenReturn(Optional.empty());

        // Act
        Template updatedTemplate = templateService.editTemplate(template, user);

        // Assert
        assertNull(updatedTemplate);
        verify(templateRepository, times(1)).findById(template.getId());
    }

    @Test
    void testDisableTemplate_Success() {
        // Configura tu Template de prueba y el usuario que está deshabilitando
        Template template = new Template();
        template.setId(1L); // Asegúrate de que el ID sea correcto
        template.setTemplateName("Template to be disabled");

        User user = new User();
        user.setId(1L); // Configura el ID del usuario para el mock

        // Configura el mock del repositorio para devolver el template adecuado
        when(templateRepository.findById(1L)).thenReturn(Optional.of(template)); // Mock para devolver el template con
                                                                                 // ID 1L
        when(templateRepository.save(any(Template.class))).thenReturn(template); // Mock para guardar el template

        // Llama al método que estás probando
        Template disabledTemplate = templateService.disableTemplate(template, user);

        // Verifica que el resultado no sea nulo
        assertNotNull(disabledTemplate, "Template should not be null");

        // Verifica que el template esté deshabilitado y que la fecha no sea nula
        assertNotNull(disabledTemplate.getDisabledAt(), "Template should be disabled.");
    }

    @Test
    public void testDisableTemplate_NotFound() {
        // Arrange
        Template template = new Template();
        template.setId(1L);

        when(templateRepository.findById(template.getId())).thenReturn(Optional.empty());

        // Act
        Template disabledTemplate = templateService.disableTemplate(template, user);

        // Assert
        assertNull(disabledTemplate);
        verify(templateRepository, times(1)).findById(template.getId());
    }

    @Test
    public void testFindById_Success() {
        // Arrange
        Long id = 1L;
        Template template = new Template();
        template.setId(id);

        when(templateRepository.findById(id)).thenReturn(Optional.of(template));

        // Act
        Optional<Template> result = templateService.findById(id);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(id, result.get().getId());
        verify(templateRepository, times(1)).findById(id);
    }

    @Test
    public void testFindById_NotFound() {
        // Arrange
        Long id = 1L;

        when(templateRepository.findById(id)).thenReturn(Optional.empty());

        // Act
        Optional<Template> result = templateService.findById(id);

        // Assert
        assertFalse(result.isPresent());
        verify(templateRepository, times(1)).findById(id);
    }
}
