package com.ideit.visionova.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class UserTest {

    @Mock
    private User mockUser;

    @Mock
    private Role mockRole;

    private User user;

    @BeforeEach
    void setUp() {
        user = new User();
    }

    @Test
    void testSetAndGetLogin() {
        user.setLogin("testUser");
        assertEquals("testUser", user.getLogin());
    }

    @Test
    void testSetAndGetPassword() {
        user.setPassword("password123");
        assertEquals("password123", user.getPassword());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date now = new Date();
        user.setCreatedAt(now);
        assertEquals(now, user.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        user.setCreatedBy(mockUser);
        assertEquals(mockUser, user.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date now = new Date();
        user.setModifiedAt(now);
        assertEquals(now, user.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        user.setModifiedBy(mockUser);
        assertEquals(mockUser, user.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date now = new Date();
        user.setDisabledAt(now);
        assertEquals(now, user.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        user.setDisabledBy(mockUser);
        assertEquals(mockUser, user.getDisabledBy());
    }

    @Test
    void testSetAndGetEnabled() {
        user.setEnabled(false);
        assertFalse(user.getEnabled());
    }

    @Test
    void testAddRole() {
        user.getRoles().add(mockRole);
        assertTrue(user.getRoles().contains(mockRole));
    }

    @Test
    void testRemoveRole() {
        user.getRoles().add(mockRole);
        user.getRoles().remove(mockRole);
        assertFalse(user.getRoles().contains(mockRole));
    }

    @Test
    void testToString() {
        user.setLogin("testUser");
        user.setPassword("password123");

        assertTrue(user.toString().contains("testUser"));
        assertTrue(user.toString().contains("password123"));
    }

    @Test
    void testEqualsAndHashCode() {
        User anotherUser = new User();
        anotherUser.setLogin("testUser");
        anotherUser.setPassword("password123");

        user.setLogin("testUser");
        user.setPassword("password123");

        assertEquals(user, anotherUser);
        assertEquals(user.hashCode(), anotherUser.hashCode());
    }
}
