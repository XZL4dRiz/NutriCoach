package com.ideit.visionova.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ideit.visionova.Jwt.JwtUtils;
import com.ideit.visionova.config.TestSecurityConfig;
import com.ideit.visionova.controller.AuthenticationController.LoginRequest;
import com.ideit.visionova.entities.RefreshToken;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.security.service.RefreshTokenService;
import com.ideit.visionova.security.service.UserDetailsImpl;

import jakarta.servlet.http.HttpServletRequest;

import com.ideit.visionova.repository.RoleRepository;
import com.ideit.visionova.repository.UserRepository;

@WebMvcTest(AuthenticationController.class)
@Import(TestSecurityConfig.class)
public class AuthenticationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private JwtUtils jwtUtils;

    @MockBean
    private RefreshTokenService refreshTokenService;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private RoleRepository roleRepository;

    @Test
    public void whoamiTest() throws Exception {
        UserDetailsImpl userDetails = new UserDetailsImpl(1L, "user", "password", Arrays.asList());
        SecurityContextHolder.getContext()
                .setAuthentication(Mockito.mock(org.springframework.security.core.Authentication.class));
        when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(userDetails);

        mockMvc.perform(get("/api/auth/whoami"))
                .andExpect(status().isOk())
                .andExpect(content().json("{id: 1, username: \"user\", roles: []}"));
    }

    @Test
    public void signoutTest() throws Exception {
        ResponseCookie jwtCookie = ResponseCookie.from("jwt", "").path("/").build();
        ResponseCookie refreshTokenCookie = ResponseCookie.from("refreshToken", "").path("/").build();
        when(jwtUtils.getCleanJwtCookie()).thenReturn(jwtCookie);
        when(jwtUtils.getCleanJwtRefreshTokenCookie()).thenReturn(refreshTokenCookie);

        mockMvc.perform(post("/api/auth/signout"))
                .andExpect(status().isOk())
                .andExpect(header().stringValues(HttpHeaders.SET_COOKIE, jwtCookie.toString(),
                        refreshTokenCookie.toString()))
                .andExpect(content().json("{message: \"You've been signed out!\"}"));
    }

    @Test
    public void refreshtokenTest() throws Exception {
        // Usuario y refreshToken de prueba
        User user = new User();
        user.setId(1L);
        user.setLogin("user");
    
        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setUser(user);
        refreshToken.setToken("validToken");
    
        // Creamos las cookies de respuesta
        ResponseCookie jwtCookie = ResponseCookie.from("jwt", "newToken").build();
        ResponseCookie refreshTokenCookie = ResponseCookie.from("refreshToken", "newToken").build();
    
        // Mocks para simular el comportamiento del refresh token y JWT
        when(jwtUtils.getJwtFromCookies(any(HttpServletRequest.class))).thenReturn("validToken");
        when(refreshTokenService.findByToken("validToken")).thenReturn(Optional.of(refreshToken));
        when(refreshTokenService.verifyExpiration(any(RefreshToken.class))).thenReturn(refreshToken);
        when(jwtUtils.generateJwtCookie(any(String.class))).thenReturn(jwtCookie);
        when(jwtUtils.generateRefreshTokenCookie(any(RefreshToken.class))).thenReturn(refreshTokenCookie);
    
        // Simula el contexto de seguridad (Autenticación)
        UserDetailsImpl userDetails = new UserDetailsImpl(1L, "user", "password", new ArrayList<>());
        Authentication authentication = Mockito.mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(userDetails);
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        securityContext.setAuthentication(authentication);
        SecurityContextHolder.setContext(securityContext);
    
        // Realiza la prueba incluyendo el JWT en el header Authorization
        mockMvc.perform(post("/api/auth/refreshtoken")
                .header("Authorization", "Bearer validToken")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())  // Esperar un 200 OK
                .andExpect(header().string(HttpHeaders.SET_COOKIE, "jwt=newToken; Path=/api; HttpOnly; Secure; SameSite=Strict"))
                .andExpect(header().string(HttpHeaders.SET_COOKIE, "refreshToken=newToken; Path=/api; HttpOnly; Secure; SameSite=Strict"))
                .andExpect(content().json("{\"message\": \"Hello again user\"}"));
    }
    

    @Test
    public void authenticateUserTest() throws Exception {
        // Simulación del loginRequest
        LoginRequest loginRequest = new LoginRequest("user", "password");

        // Simulación del comportamiento del AuthenticationManager
        Authentication authentication = Mockito.mock(Authentication.class);
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(authentication);

        UserDetailsImpl userDetails = new UserDetailsImpl(1L, "user", "password", new ArrayList<>());
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        securityContext.setAuthentication(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getPrincipal()).thenReturn(userDetails);

        // Crear una instancia de User basada en UserDetailsImpl
        User user = new User();
        user.setId(userDetails.getId());
        user.setLogin(userDetails.getUsername());
        // Agrega otros campos necesarios de User aquí

        // Simulación de las cookies JWT
        ResponseCookie jwtCookie = ResponseCookie.from("jwt", "token").build();
        ResponseCookie refreshTokenCookie = ResponseCookie.from("refreshToken", "token").build();
        when(jwtUtils.generateJwtCookie(any(UserDetailsImpl.class))).thenReturn(jwtCookie);
        when(jwtUtils.generateRefreshTokenCookie(any(RefreshToken.class))).thenReturn(refreshTokenCookie);

        // Simulación de la creación del refresh token
        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setId(1L);
        refreshToken.setUser(user); // Cambiado para usar el objeto User
        refreshToken.setToken("token");
        refreshToken.setExpiryDate(Instant.now().plusSeconds(3600));
        when(refreshTokenService.createRefreshToken(any(Long.class))).thenReturn(refreshToken);

        mockMvc.perform(post("/api/auth/signin")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(header().stringValues(HttpHeaders.SET_COOKIE, jwtCookie.toString(),
                        refreshTokenCookie.toString())) // Usa stringValues en lugar de string
                .andExpect(content().json("{id: 1, username: \"user\", roles: [], idCustomer: 1}"));

    }

    // Método auxiliar para convertir objeto a JSON
    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
