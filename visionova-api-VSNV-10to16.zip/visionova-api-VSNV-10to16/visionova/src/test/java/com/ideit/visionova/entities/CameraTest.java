package com.ideit.visionova.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class CameraTest {

    @Mock
    private User mockUser;

    private Camera camera;

    @BeforeEach
    void setUp() {
        camera = new Camera();
    }

    @Test
    void testDefaultValues() {
        assertNotNull(camera.getCreatedAt());
        assertTrue(camera.getActive());
        assertTrue(camera.getEnabled());
    }

    @Test
    void testSetAndGetLocation() {
        camera.setLocation("Front Gate");
        assertEquals("Front Gate", camera.getLocation());
    }

    @Test
    void testSetAndGetType() {
        camera.setType("IP Camera");
        assertEquals("IP Camera", camera.getType());
    }

    @Test
    void testSetAndGetSource() {
        String sourceUrl = "http://camera-feed.com/stream";
        camera.setSource(sourceUrl);
        assertEquals(sourceUrl, camera.getSource());
    }

    @Test
    void testSetAndGetActive() {
        camera.setActive(false);
        assertFalse(camera.getActive());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date now = new Date();
        camera.setCreatedAt(now);
        assertEquals(now, camera.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        camera.setCreatedBy(mockUser);
        assertEquals(mockUser, camera.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date now = new Date();
        camera.setModifiedAt(now);
        assertEquals(now, camera.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        camera.setModifiedBy(mockUser);
        assertEquals(mockUser, camera.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date now = new Date();
        camera.setDisabledAt(now);
        assertEquals(now, camera.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        camera.setDisabledBy(mockUser);
        assertEquals(mockUser, camera.getDisabledBy());
    }

    @Test
    void testSetAndGetEnabled() {
        camera.setEnabled(false);
        assertFalse(camera.getEnabled());
    }

    @Test
    void testToString() {
        camera.setLocation("Front Gate");
        camera.setType("IP Camera");
        camera.setSource("http://camera-feed.com/stream");

        assertTrue(camera.toString().contains("Front Gate"));
        assertTrue(camera.toString().contains("IP Camera"));
    }

    @Test
    void testEqualsAndHashCode() {
        Camera anotherCamera = new Camera();
        anotherCamera.setLocation("Front Gate");
        anotherCamera.setType("IP Camera");
        anotherCamera.setSource("http://camera-feed.com/stream");

        camera.setLocation("Front Gate");
        camera.setType("IP Camera");
        camera.setSource("http://camera-feed.com/stream");

        assertEquals(camera, anotherCamera);
        assertEquals(camera.hashCode(), anotherCamera.hashCode());
    }
}
