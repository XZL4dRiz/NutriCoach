package com.ideit.visionova.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AnalysisProcessTemplateTest {

    private AnalysisProcessTemplate analysisProcessTemplate;

    @BeforeEach
    void setUp() {
        analysisProcessTemplate = new AnalysisProcessTemplate();
    }

    @Test
    void testDefaultValues() {
        assertNotNull(analysisProcessTemplate);
        assertNull(analysisProcessTemplate.getId());
        assertNull(analysisProcessTemplate.getAnalysisProcess());
        assertNull(analysisProcessTemplate.getTemplate());
        assertNull(analysisProcessTemplate.getParameters());
        assertNull(analysisProcessTemplate.getCreatedAt());
        assertNull(analysisProcessTemplate.getCreatedBy());
        assertNull(analysisProcessTemplate.getModifiedAt());
        assertNull(analysisProcessTemplate.getModifiedBy());
        assertNull(analysisProcessTemplate.getDisabledAt());
        assertNull(analysisProcessTemplate.getDisabledBy());
        assertTrue(analysisProcessTemplate.getEnabled());  // Default value is true
    }

    @Test
    void testSetAndGetAnalysisProcessId() {
        Long analysisProcessId = 123L;
        analysisProcessTemplate.setanalysisProcessId(analysisProcessId);
        assertEquals(analysisProcessId, analysisProcessTemplate.getanalysisProcessId());
    }

    @Test
    void testSetAndGetTemplateId() {
        Long templateId = 456L;
        analysisProcessTemplate.settemplateId(templateId);
        assertEquals(templateId, analysisProcessTemplate.gettemplateId());
    }

    @Test
    void testSetAndGetParameters() {
        String parameters = "param1=value1,param2=value2";
        analysisProcessTemplate.setParameters(parameters);
        assertEquals(parameters, analysisProcessTemplate.getParameters());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date createdAt = new Date();
        analysisProcessTemplate.setCreatedAt(createdAt);
        assertEquals(createdAt, analysisProcessTemplate.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        User user = new User(); // Assuming User is a valid class
        analysisProcessTemplate.setCreatedBy(user);
        assertEquals(user, analysisProcessTemplate.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date modifiedAt = new Date();
        analysisProcessTemplate.setModifiedAt(modifiedAt);
        assertEquals(modifiedAt, analysisProcessTemplate.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        User user = new User(); // Assuming User is a valid class
        analysisProcessTemplate.setModifiedBy(user);
        assertEquals(user, analysisProcessTemplate.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date disabledAt = new Date();
        analysisProcessTemplate.setDisabledAt(disabledAt);
        assertEquals(disabledAt, analysisProcessTemplate.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        User user = new User(); // Assuming User is a valid class
        analysisProcessTemplate.setDisabledBy(user);
        assertEquals(user, analysisProcessTemplate.getDisabledBy());
    }

    @Test
    void testSetAndGetEnabled() {
        analysisProcessTemplate.setEnabled(false);
        assertFalse(analysisProcessTemplate.getEnabled());
    }
}
