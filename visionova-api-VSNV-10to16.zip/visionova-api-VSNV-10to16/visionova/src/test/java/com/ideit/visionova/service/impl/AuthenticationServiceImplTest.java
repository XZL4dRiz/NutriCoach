package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.Role;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.Jwt.JwtUtils;
import com.ideit.visionova.repository.UserRepository;
import com.ideit.visionova.repository.RoleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AuthenticationServiceImplTest {

    @InjectMocks
    private AuthenticationServiceImpl authenticationService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtils jwtTokenUtil;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAuthenticate_Success() {
        // Arrange
        String username = "testUser";
        String password = "testPassword";
        User user = new User();
        user.setLogin(username);
        user.setPassword("encodedPassword");

        when(userRepository.findByLogin(username)).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(password, user.getPassword())).thenReturn(true);

        // Act
        Optional<User> result = authenticationService.authenticate(username, password);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(username, result.get().getLogin());
        verify(userRepository, times(1)).findByLogin(username);
        verify(passwordEncoder, times(1)).matches(password, user.getPassword());
    }

    @Test
    public void testAuthenticate_Failure() {
        // Arrange
        String username = "testUser";
        String password = "testPassword";

        when(userRepository.findByLogin(username)).thenReturn(Optional.empty());

        // Act
        Optional<User> result = authenticationService.authenticate(username, password);

        // Assert
        assertFalse(result.isPresent());
        verify(userRepository, times(1)).findByLogin(username);
        verify(passwordEncoder, never()).matches(anyString(), anyString());
    }

    @Test
    public void testGetUserFromToken_Success() {
        // Arrange
        String token = "validToken";
        String username = "testUser";
        User user = new User();
        user.setLogin(username);

        when(jwtTokenUtil.getUserNameFromJwtToken(token)).thenReturn(username);
        when(userRepository.findByLogin(username)).thenReturn(Optional.of(user));

        // Act
        User result = authenticationService.getUserFromToken(token);

        // Assert
        assertNotNull(result);
        assertEquals(username, result.getLogin());
        verify(jwtTokenUtil, times(1)).getUserNameFromJwtToken(token);
        verify(userRepository, times(1)).findByLogin(username);
    }

    @Test
    public void testGetUserFromToken_UserNotFound() {
        // Arrange
        String token = "validToken";
        String username = "testUser";

        when(jwtTokenUtil.getUserNameFromJwtToken(token)).thenReturn(username);
        when(userRepository.findByLogin(username)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(UsernameNotFoundException.class, () -> authenticationService.getUserFromToken(token));
        verify(jwtTokenUtil, times(1)).getUserNameFromJwtToken(token);
        verify(userRepository, times(1)).findByLogin(username);
    }

    @Test
    public void testRegisterUser_Success() {
        // Arrange
        User user = new User();
        user.setPassword("rawPassword");

        Role role = new Role();
        role.setName("ROLE_USER");

        when(roleRepository.findByName("ROLE_USER")).thenReturn(Optional.of(role));
        when(passwordEncoder.encode("rawPassword")).thenReturn("encodedPassword");
        when(userRepository.save(user)).thenReturn(user);

        // Act
        User result = authenticationService.registerUser(user);

        // Assert
        assertNotNull(result);
        assertEquals("encodedPassword", result.getPassword());
        assertTrue(result.getRoles().contains(role));
        verify(roleRepository, times(1)).findByName("ROLE_USER");
        verify(passwordEncoder, times(1)).encode("rawPassword");
        verify(userRepository, times(1)).save(user);
    }

    @Test
    public void testIsUsernameTaken() {
        // Arrange
        String username = "testUser";

        when(userRepository.existsByLogin(username)).thenReturn(true);

        // Act
        boolean result = authenticationService.isUsernameTaken(username);

        // Assert
        assertTrue(result);
        verify(userRepository, times(1)).existsByLogin(username);
    }

    @Test
    public void testGenerateJwtToken() {
        // Arrange
        User user = new User();
        user.setLogin("testUser");

        when(jwtTokenUtil.generateTokenFromUsername(user.getLogin())).thenReturn("generatedToken");

        // Act
        String token = authenticationService.generateJwtToken(user);

        // Assert
        assertEquals("generatedToken", token);
        verify(jwtTokenUtil, times(1)).generateTokenFromUsername(user.getLogin());
    }
}
