package com.ideit.visionova.controller;

import com.ideit.visionova.entities.Role;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.RoleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class RoleControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RoleService roleService;

    @InjectMocks
    private RoleController roleController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(roleController).build();

        // Simular un usuario autenticado de la clase User
        User user = new User();
        user.setId(1L);
        user.setLogin("testUser");
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(user, null);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    

    @Test
    public void testCreateRole() throws Exception {
        Role role = new Role();
        role.setName("New Role");

        User user = new User();
        user.setId(1L);

        given(roleService.createRole(any(Role.class), any(User.class))).willReturn(role);

        mockMvc.perform(post("/api/roles")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"name\": \"New Role\" }")
                .param("userId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(role.getName()));
    }

    @Test public void testModifyRole() throws Exception {
        Role role = new Role();
        role.setId(1L); 
        role.setName("Updated Role"); 
        User user = new User(); 
        user.setId(1L); 
        given(roleService.modifyRole(any(Role.class), any(User.class))).willReturn(role);
        mockMvc.perform(put("/api/roles/{id}", role.getId()) 
            .contentType(MediaType.APPLICATION_JSON) 
            .content("{ \"name\": \"Updated Role\" }") .param("userId", "1")) 
            .andExpect(status().isOk()) 
            .andExpect(jsonPath("$.name")
            .value(role.getName()));
    }

    @Test
    public void testDisableRole() throws Exception {
        Role role = new Role();
        role.setId(1L);
        role.setName("Disabled Role");

        User user = new User();
        user.setId(1L);

        given(roleService.disableRole(any(Role.class), any(User.class))).willReturn(role);

        mockMvc.perform(patch("/api/roles/{id}/disable", role.getId())
                .param("userId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(role.getName()));
    }
}
