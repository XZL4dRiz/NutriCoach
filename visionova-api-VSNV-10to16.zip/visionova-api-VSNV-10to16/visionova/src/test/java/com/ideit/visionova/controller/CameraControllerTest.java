package com.ideit.visionova.controller;

import com.ideit.visionova.entities.Camera;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.CameraService;
import com.ideit.visionova.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class CameraControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CameraService cameraService;

    @Mock
    private UserService userService;

    @InjectMocks
    private CameraController cameraController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(cameraController).build();

        // Simular un usuario autenticado de la clase User
        User user = new User();
        user.setId(1L);
        user.setLogin("testUser");
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(user, null);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    public void testModifyCamera() throws Exception {
        Camera camera = new Camera();
        camera.setId(1L);
        camera.setLocation("Updated Location");
        camera.setType("Updated Type");
        camera.setActive(true);
        camera.setSource("Updated Source");

        User user = new User();
        user.setId(1L);

        given(userService.findById(user.getId())).willReturn(Optional.of(user));
        given(cameraService.modifyCamera(any(Camera.class), any(User.class))).willReturn(camera);

        mockMvc.perform(put("/cameras/{id}", camera.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"location\": \"Updated Location\", \"type\": \"Updated Type\", \"active\": true, \"source\": \"Updated Source\" }")
                .param("userId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.location").value(camera.getLocation()))
                .andExpect(jsonPath("$.type").value(camera.getType()))
                .andExpect(jsonPath("$.active").value(camera.getActive()))
                .andExpect(jsonPath("$.source").value(camera.getSource()));
    }
}
