package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.AnalysisProcess;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.AnalysisProcessRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AnalysisProcessServiceImplTest {

    @InjectMocks
    private AnalysisProcessServiceImpl analysisProcessService;

    @Mock
    private EntityManager entityManager;

    @Mock
    private AnalysisProcessRepository analysisProcessRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        analysisProcessService.setEntityManager(entityManager);
    }

    @Test
    public void testCreateAnalysisProcess_Success() {
        // Arrange
        AnalysisProcess analysisProcess = new AnalysisProcess();
        analysisProcess.setName("Test Process");
        User user = new User();
        user.setId(1L);

        when(entityManager.find(User.class, user.getId())).thenReturn(user);
        when(analysisProcessRepository.save(analysisProcess)).thenReturn(analysisProcess);

        // Act
        AnalysisProcess result = analysisProcessService.createAnalysisProcess(analysisProcess, user);

        // Assert
        assertNotNull(result);
        assertEquals(analysisProcess.getName(), result.getName());
        verify(entityManager, times(1)).find(User.class, user.getId());
        verify(analysisProcessRepository, times(1)).save(analysisProcess);
    }

    @Test
    public void testModifyAnalysisProcess_Success() {
        // Arrange
        AnalysisProcess existingProcess = new AnalysisProcess();
        existingProcess.setId(1L);
        existingProcess.setName("Existing Process");

        AnalysisProcess modifiedProcess = new AnalysisProcess();
        modifiedProcess.setId(1L);
        modifiedProcess.setName("Modified Process");

        User user = new User();
        user.setId(1L);

        when(analysisProcessRepository.findById(existingProcess.getId())).thenReturn(Optional.of(existingProcess));
        when(entityManager.find(User.class, user.getId())).thenReturn(user);
        when(entityManager.merge(modifiedProcess)).thenReturn(modifiedProcess);

        // Act
        AnalysisProcess result = analysisProcessService.modifyAnalysisProcess(modifiedProcess, user);

        // Assert
        assertNotNull(result);
        assertEquals("Modified Process", result.getName());
        verify(analysisProcessRepository, times(1)).findById(existingProcess.getId());
        verify(entityManager, times(1)).find(User.class, user.getId());
        verify(entityManager, times(1)).merge(modifiedProcess);
    }

    @Test
    public void testModifyAnalysisProcess_NotFound() {
        // Arrange
        AnalysisProcess modifiedProcess = new AnalysisProcess();
        modifiedProcess.setId(1L);
        User user = new User();
        user.setId(1L);

        when(analysisProcessRepository.findById(modifiedProcess.getId())).thenReturn(Optional.empty());

        // Act
        AnalysisProcess result = analysisProcessService.modifyAnalysisProcess(modifiedProcess, user);

        // Assert
        assertNull(result);
        verify(analysisProcessRepository, times(1)).findById(modifiedProcess.getId());
        verify(entityManager, never()).find(User.class, user.getId());
        verify(entityManager, never()).merge(modifiedProcess);
    }

    @Test
    public void testDisableAnalysisProcess_Success() {
        // Arrange
        AnalysisProcess existingProcess = new AnalysisProcess();
        existingProcess.setId(1L);
        existingProcess.setName("Existing Process");
        User user = new User();
        user.setId(1L);

        when(analysisProcessRepository.findById(existingProcess.getId())).thenReturn(Optional.of(existingProcess));
        when(entityManager.find(User.class, user.getId())).thenReturn(user);
        when(entityManager.merge(existingProcess)).thenReturn(existingProcess);

        // Act
        AnalysisProcess result = analysisProcessService.disableAnalysisProcess(existingProcess, user);

        // Assert
        assertNotNull(result);
        verify(analysisProcessRepository, times(1)).findById(existingProcess.getId());
        verify(entityManager, times(1)).find(User.class, user.getId());
        verify(entityManager, times(1)).merge(existingProcess);
    }

    @Test
    public void testDisableAnalysisProcess_NotFound() {
        // Arrange
        AnalysisProcess process = new AnalysisProcess();
        process.setId(1L);
        User user = new User();
        user.setId(1L);

        when(analysisProcessRepository.findById(process.getId())).thenReturn(Optional.empty());

        // Act
        AnalysisProcess result = analysisProcessService.disableAnalysisProcess(process, user);

        // Assert
        assertNull(result);
        verify(analysisProcessRepository, times(1)).findById(process.getId());
        verify(entityManager, never()).find(User.class, user.getId());
        verify(entityManager, never()).merge(process);
    }
}

