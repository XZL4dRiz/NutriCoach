package com.ideit.visionova.controller;

import com.ideit.visionova.Exception.ResourceNotFoundException;
import com.ideit.visionova.entities.GlobalSetting;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.GlobalSettingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class GlobalSettingControllerTest {

    @InjectMocks
    private GlobalSettingController globalSettingController;

    @Mock
    private GlobalSettingService globalSettingService;

    @Mock
    private User user; // Mock User for authentication context

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Crear un mock de Authentication
        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(user);

        // Crear un mock de SecurityContext y establecer el Authentication
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        // Establecer el SecurityContext en el SecurityContextHolder
        SecurityContextHolder.setContext(securityContext);
    }

    @SuppressWarnings("null")
    @Test
    @WithMockUser (username = "testUser ")
    void testGetAll() {
        GlobalSetting setting1 = new GlobalSetting();
        GlobalSetting setting2 = new GlobalSetting();
        when(globalSettingService.getAll()).thenReturn(Arrays.asList(setting1, setting2));

        ResponseEntity<List<GlobalSetting>> response = globalSettingController.getAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    void testGetById_Success() {
        GlobalSetting setting = new GlobalSetting();
        when(globalSettingService.findById(1L)).thenReturn(Optional.of(setting));

        ResponseEntity<GlobalSetting> response = globalSettingController.getById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(setting, response.getBody());
    }

    @Test
    void testGetById_NotFound() {
        when(globalSettingService.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            globalSettingController.getById(1L);
        });
    }

    @Test
    void testCreate() throws Exception {
        GlobalSetting newSetting = new GlobalSetting();
        when(globalSettingService.createGlobalSetting(any(GlobalSetting.class), eq(user))).thenReturn(newSetting);

        ResponseEntity<GlobalSetting> response = globalSettingController.create(newSetting);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(newSetting, response.getBody());
    }

    @Test
    void testCreate_UnauthenticatedUser () {
        // Simular que el usuario no está autenticado
        when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(null);

        GlobalSetting newSetting = new GlobalSetting();

        Exception exception = assertThrows(Exception.class, () -> {
            globalSettingController.create(newSetting);
        });

        assertEquals("Usuario no autenticado", exception.getMessage());
    }

    @Test
    void testUpdate_Success() throws Exception {
        GlobalSetting existingSetting = new GlobalSetting();
        existingSetting.setId(1L);
        when(globalSettingService.findById(1L)).thenReturn(Optional.of(existingSetting));
        when(globalSettingService.editGlobalSetting(any(GlobalSetting.class), eq(user))).thenReturn(existingSetting);

        ResponseEntity<GlobalSetting> response = globalSettingController.update(1L, existingSetting);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(existingSetting, response.getBody());
    }

    @Test
    void testUpdate_NotFound() {
        GlobalSetting updatedSetting = new GlobalSetting();
        when(globalSettingService.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            globalSettingController.update(1L, updatedSetting);
        });
    }

    @Test
    void testDelete_Success() {
        GlobalSetting existingSetting = new GlobalSetting();
        existingSetting.setId(1L);
        when(globalSettingService.findById(1L)).thenReturn(Optional.of(existingSetting));

        ResponseEntity<HttpStatus> response = globalSettingController.delete(1L);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        verify(globalSettingService).disableGlobalSetting(existingSetting, user);
    }

    @Test
    void testDelete_NotFound() {
        when(globalSettingService.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            globalSettingController.delete( 1L);
        });
    }

    @Test
    void testDelete_Unauthorized() {
        // Simular que el usuario no está autenticado
        when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(null);

        ResponseEntity<HttpStatus> response = globalSettingController.delete(1L);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }
}