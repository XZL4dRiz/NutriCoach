package com.ideit.visionova.controller;

import com.ideit.visionova.entities.Template;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.TemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class TemplateControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TemplateService templateService;

    @InjectMocks
    private TemplateController templateController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(templateController).build();

        // Simular un usuario autenticado de la clase User
        User user = new User();
        user.setId(1L);
        user.setLogin("testUser");
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(user, null);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    public void testGetAllTemplates() throws Exception {
        Template template = new Template();
        template.setId(1L);
        template.setTemplateName("Test Template");

        given(templateService.getAll()).willReturn(Arrays.asList(template));

        mockMvc.perform(get("/templates")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(template.getId()))
                .andExpect(jsonPath("$[0].templateName").value(template.getTemplateName()));
    }

    @Test
    public void testGetTemplateById() throws Exception {
        Template template = new Template();
        template.setId(1L);
        template.setTemplateName("Test Template");

        given(templateService.findById(template.getId())).willReturn(Optional.of(template));

        mockMvc.perform(get("/templates/{id}", template.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(template.getId()))
                .andExpect(jsonPath("$.templateName").value(template.getTemplateName()));
    }

    @Test
    public void testCreateTemplate() throws Exception {
        Template template = new Template();
        template.setId(1L);
        template.setTemplateName("New Template");
        User user = new User();
        user.setId(1L);

        given(templateService.createTemplate(any(Template.class), any(User.class))).willReturn(template);

        mockMvc.perform(post("/templates")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{ \"templateName\": \"New Template\", \"coordinates\": \"[]\" }"))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.templateName").value(template.getTemplateName()));
    }


    @Test
    public void testEditTemplate() throws Exception {
        Template template = new Template();
        template.setId(1L);
        template.setTemplateName("Updated Template");
        template.setCoordinates("[]");
        User user = new User();
        user.setId(1L);

        given(templateService.findById(template.getId())).willReturn(Optional.of(template));
        given(templateService.editTemplate(any(Template.class), any(User.class))).willReturn(template);

        mockMvc.perform(put("/templates/{id}", template.getId())
            .contentType(MediaType.APPLICATION_JSON)
            .content("{ \"templateName\": \"Updated Template\", \"coordinates\": \"[]\" }"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.templateName").value(template.getTemplateName()));
    }


    @Test
    public void testDeleteTemplate() throws Exception {
        Template template = new Template();
        template.setId(1L);
        User user = new User();
        user.setId(1L);

        given(templateService.findById(template.getId())).willReturn(Optional.of(template));

        mockMvc.perform(delete("/templates/{id}", template.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }
}
