package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.Role;
import com.ideit.visionova.entities.User;

import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class RoleServiceImplTest {

    @Autowired
    private RoleServiceImpl roleService;

    @Autowired
    private EntityManager entityManager;

    private Role role;
    private User user;

    @BeforeEach
    void setUp() {
        // Crear un usuario ficticio para las pruebas
        user = new User();
        user.setLogin("testUser");
        user.setPassword("password");
        user = entityManager.merge(user);

        // Crear un rol ficticio para las pruebas y asociarlo con el usuario
        role = new Role();
        role.setName("testRole");
        role.setCreatedAt(new Date());
        role.setCreatedBy(user);
        role = entityManager.merge(role);
    }

    @Test
    @Transactional
    void testCreateRole() {
        Role newRole = new Role();
        newRole.setName("newRole");

        Role createdRole = roleService.createRole(newRole, user);

        assertNotNull(createdRole);
        assertEquals(newRole.getName(), createdRole.getName());
        assertNotNull(createdRole.getId());
    }

    @Test
    @Transactional
    void testModifyRole() {
        role.setName("modifiedRole");
        Role updatedRole = roleService.modifyRole(role, user);

        assertNotNull(updatedRole);
        assertEquals("modifiedRole", updatedRole.getName());
    }

    @Test
    @Transactional
    void testDisableRole() {
        Role disabledRole = roleService.disableRole(role, user);

        assertNotNull(disabledRole);
        // Añadir validación específica para el campo de estado
        assertFalse(disabledRole.getEnabled(), "El rol debería estar deshabilitado");
    }

    @Test
    @Transactional
    void testFindById() {
        Optional<Role> foundRole = roleService.findById(role.getId());

        assertTrue(foundRole.isPresent());
        assertEquals(role.getName(), foundRole.get().getName());
    }
}