package com.ideit.visionova.controller;

import com.ideit.visionova.entities.AnalysisProcess;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.AnalysisProcessService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class AnalysisProcessControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AnalysisProcessService analysisProcessService;

    @InjectMocks
    private AnalysisProcessController analysisProcessController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(analysisProcessController).build();

        // Simular un usuario autenticado de la clase User
        User user = new User();
        user.setId(1L);
        user.setLogin("testUser");
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(user, null);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    public void testModifyAnalysisProcess() throws Exception {
        AnalysisProcess analysisProcess = new AnalysisProcess();
        analysisProcess.setId(1L);
        analysisProcess.setName("Updated Analysis Process");
        analysisProcess.setDescription("Updated Description");
        User user = new User();
        user.setId(1L);

        given(analysisProcessService.findById(analysisProcess.getId())).willReturn(Optional.of(analysisProcess));
        given(analysisProcessService.modifyAnalysisProcess(any(AnalysisProcess.class), any(User.class))).willReturn(analysisProcess);

        mockMvc.perform(put("/analysis-processes/{id}", analysisProcess.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"name\": \"Updated Analysis Process\", \"description\": \"Updated Description\", \"cameraId\": 1 }")
                .param("userId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(analysisProcess.getName()))
                .andExpect(jsonPath("$.description").value(analysisProcess.getDescription()));
    }

    @Test
    public void testCreateAnalysisProcess() throws Exception {
        AnalysisProcess analysisProcess = new AnalysisProcess();
        analysisProcess.setId(1L);
        analysisProcess.setName("New Analysis Process");
        analysisProcess.setDescription("Description of the new process");

        User user = new User();
        user.setId(1L);

        given(analysisProcessService.createAnalysisProcess(any(AnalysisProcess.class), any(User.class)))
            .willReturn(analysisProcess);

        mockMvc.perform(post("/analysis-processes")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{ \"name\": \"New Analysis Process\", \"description\": \"Description of the new process\" }")
            .param("userId", "1"))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.name").value(analysisProcess.getName()))
            .andExpect(jsonPath("$.description").value(analysisProcess.getDescription()));
    }

    @Test
    public void testDisableAnalysisProcess() throws Exception {
        Long processId = 1L;
        AnalysisProcess analysisProcess = new AnalysisProcess();
        analysisProcess.setId(processId);
        analysisProcess.setName("Process to disable");
        analysisProcess.setDescription("Some description");

     User user = new User();
        user.setId(1L);

        given(analysisProcessService.findById(processId)).willReturn(Optional.of(analysisProcess));
        given(analysisProcessService.disableAnalysisProcess(any(AnalysisProcess.class), any(User.class)))
            .willReturn(analysisProcess);

        mockMvc.perform(patch("/analysis-processes/{id}/disable", processId)
            .param("userId", "1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value(analysisProcess.getName()))
            .andExpect(jsonPath("$.description").value(analysisProcess.getDescription()));
    }
    @Test
    public void testGetAnalysisProcess() throws Exception {
        Long processId = 1L;
        AnalysisProcess analysisProcess = new AnalysisProcess();
        analysisProcess.setId(processId);
        analysisProcess.setName("Existing Process");
        analysisProcess.setDescription("Some description");

        given(analysisProcessService.findById(processId)).willReturn(Optional.of(analysisProcess));

        mockMvc.perform(get("/analysis-processes/{id}", processId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value(analysisProcess.getName()))
            .andExpect(jsonPath("$.description").value(analysisProcess.getDescription()));
    }

    @Test
    public void testGetAllAnalysisProcesses() throws Exception {
        AnalysisProcess analysisProcess1 = new AnalysisProcess();
        analysisProcess1.setId(1L);
        analysisProcess1.setName("Process 1");
        analysisProcess1.setDescription("Description 1");

        AnalysisProcess analysisProcess2 = new AnalysisProcess();
        analysisProcess2.setId(2L);
        analysisProcess2.setName("Process 2");
        analysisProcess2.setDescription("Description 2");

        Iterable<AnalysisProcess> analysisProcesses = List.of(analysisProcess1, analysisProcess2);
        given(analysisProcessService.findByEnabled(true)).willReturn(analysisProcesses);

        mockMvc.perform(get("/analysis-processes"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].name").value(analysisProcess1.getName()))
            .andExpect(jsonPath("$[1].name").value(analysisProcess2.getName()));
    }



}

