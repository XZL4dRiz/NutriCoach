package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.Camera;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.CameraRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CameraServiceImplTest {

    @InjectMocks
    private CameraServiceImpl cameraService;

    @Mock
    private EntityManager entityManager;

    @Mock
    private CameraRepository cameraRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        cameraService.setEntityManager(entityManager);
    }

    @Test
    public void testCreateCamera_Success() {
        // Arrange
        Camera camera = new Camera();
        camera.setSource("Camera1");
        User user = new User();
        user.setId(1L);

        when(entityManager.find(User.class, user.getId())).thenReturn(user);
        when(cameraRepository.save(camera)).thenReturn(camera);

        // Act
        Camera result = cameraService.createCamera(camera, user);

        // Assert
        assertNotNull(result);
        assertEquals(camera.getSource(), result.getSource());
        verify(entityManager, times(1)).find(User.class, user.getId());
        verify(cameraRepository, times(1)).save(camera);
    }

    @Test
    public void testModifyCamera_Success() {
        // Arrange
        Camera camera = new Camera();
        camera.setId(1L);
        camera.setSource("UpdatedSource");

        User user = new User();
        user.setId(1L);

        Camera existingCamera = new Camera();
        existingCamera.setId(1L);
        existingCamera.setSource("OldSource");

        when(cameraRepository.findById(camera.getId())).thenReturn(Optional.of(existingCamera));
        when(entityManager.find(User.class, user.getId())).thenReturn(user);
        when(cameraRepository.save(existingCamera)).thenReturn(existingCamera); // Ensure save returns the updated
                                                                                // camera

        // Act
        Camera result = cameraService.modifyCamera(camera, user);

        // Assert
        assertNotNull(result);
        assertEquals("UpdatedSource", result.getSource());
        verify(cameraRepository, times(1)).findById(camera.getId());
        verify(cameraRepository, times(1)).save(existingCamera);
    }

    @Test
    public void testDisableCamera_Success() {
        // Arrange
        Camera camera = new Camera();
        camera.setId(1L);
        camera.setSource("OldSource");
        User user = new User();
        user.setId(1L);

        Camera existingCamera = new Camera();
        existingCamera.setId(1L);
        existingCamera.setSource("OldSource");

        when(cameraRepository.findById(camera.getId())).thenReturn(Optional.of(existingCamera));
        when(entityManager.find(User.class, user.getId())).thenReturn(user); // Ensure mock is correct
        when(cameraRepository.save(existingCamera)).thenReturn(existingCamera);

        // Act
        Camera result = cameraService.disableCamera(camera, user);

        // Assert
        assertNotNull(result);
        verify(entityManager, times(1)).find(User.class, user.getId()); // Ensure find is called once
        verify(cameraRepository, times(1)).findById(camera.getId());
        verify(cameraRepository, times(1)).save(existingCamera);
    }

    @Test
    public void testFindById() {
        // Arrange
        Long cameraId = 1L;
        Camera camera = new Camera();
        camera.setId(cameraId);

        when(cameraRepository.findById(cameraId)).thenReturn(Optional.of(camera));

        // Act
        Optional<Camera> result = cameraService.findById(cameraId);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(cameraId, result.get().getId());
        verify(cameraRepository, times(1)).findById(cameraId);
    }

    @Test
    public void testFindAll() {
        // Arrange
        Pageable pageable = Pageable.unpaged();
        Camera camera = new Camera();
        Page<Camera> cameras = new PageImpl<>(Collections.singletonList(camera));

        when(cameraRepository.findAll(pageable)).thenReturn(cameras);

        // Act
        Page<Camera> result = cameraService.findAll(pageable);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        verify(cameraRepository, times(1)).findAll(pageable);
    }
}
