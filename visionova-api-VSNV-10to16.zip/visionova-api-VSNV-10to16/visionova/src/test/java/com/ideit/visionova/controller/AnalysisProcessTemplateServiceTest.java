package com.ideit.visionova.controller;

import com.ideit.visionova.entities.AnalysisProcessTemplate;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.service.AnalysisProcessTemplateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class AnalysisProcessTemplateControllerTest {

    @InjectMocks
    private AnalysisProcessTemplateController analysisProcessTemplateController;

    @Mock
    private AnalysisProcessTemplateService analysisProcessTemplateService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAnalysisProcessTemplate() {
        // Preparar datos de prueba
        AnalysisProcessTemplate template = new AnalysisProcessTemplate();
        User user = new User();
        user.setId(1L);

        // Simular comportamiento del servicio
        when(analysisProcessTemplateService.createAnalysisProcessTemplate(template, user)).thenReturn(template);

        // Llamar al método del controlador
        ResponseEntity<AnalysisProcessTemplate> response = analysisProcessTemplateController.createAnalysisProcessTemplate(template, user.getId());

        // Verificar el resultado
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(template, response.getBody());
        verify(analysisProcessTemplateService, times(1)).createAnalysisProcessTemplate(template, user);
    }

    @Test
    void testModifyAnalysisProcessTemplate() {
        // Preparar datos de prueba
        AnalysisProcessTemplate template = new AnalysisProcessTemplate();
        template.setId(1L);
        User user = new User();
        user.setId(1L);

        // Simular comportamiento del servicio
        when(analysisProcessTemplateService.modifyAnalysisProcessTemplates(template, user)).thenReturn(template);

        // Llamar al método del controlador
        ResponseEntity<AnalysisProcessTemplate> response = analysisProcessTemplateController.modifyAnalysisProcessTemplate(template.getId(), template, user.getId());

        // Verificar el resultado
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(template, response.getBody());
        verify(analysisProcessTemplateService, times(1)).modifyAnalysisProcessTemplates(template, user);
    }

    @Test
    void testDisableAnalysisProcessTemplate() {
        // Preparar datos de prueba
        AnalysisProcessTemplate template = new AnalysisProcessTemplate();
        template.setId(1L);
        User user = new User();
        user.setId(1L);

        // Simular comportamiento del servicio
        when(analysisProcessTemplateService.findById(1L)).thenReturn(Optional.of(template));
        when(analysisProcessTemplateService.disableAnalysisProcessTemplate(template, user)).thenReturn(template);

        // Llamar al método del controlador
        ResponseEntity<AnalysisProcessTemplate> response = analysisProcessTemplateController.disableAnalysisProcessTemplate(1L, user.getId());

        // Verificar el resultado
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(template, response.getBody());
        verify(analysisProcessTemplateService, times(1)).findById(1L);
        verify(analysisProcessTemplateService, times(1)).disableAnalysisProcessTemplate(template, user);
    }

    @Test
    void testGetAnalysisProcessTemplate() {
        // Preparar datos de prueba
        AnalysisProcessTemplate template = new AnalysisProcessTemplate();
        template.setId(1L);

        // Simular comportamiento del servicio
        when(analysisProcessTemplateService.findById(1L)).thenReturn(Optional.of(template));

        // Llamar al método del controlador
        ResponseEntity<AnalysisProcessTemplate> response = analysisProcessTemplateController.getAnalysisProcessTemplate(1L);

        // Verificar el resultado
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(template, response.getBody());
        verify(analysisProcessTemplateService, times(1)).findById(1L);
    }

    @Test
    void testGetAllAnalysisProcessTemplates() {
        // Simular comportamiento del servicio
        Iterable<AnalysisProcessTemplate> templates = mock(Iterable.class);
        when(analysisProcessTemplateService.findByEnabled(true)).thenReturn(templates);

        // Llamar al método del controlador
        ResponseEntity<Iterable<AnalysisProcessTemplate>> response = analysisProcessTemplateController.getAllAnalysisProcessTemplates();

        // Verificar el resultado
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(templates, response.getBody());
        verify(analysisProcessTemplateService, times(1)).findByEnabled(true);
    }
}