package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.GlobalSetting;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.GlobalSettingRepository;

import jakarta.persistence.EntityManager;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class GlobalSettingServiceImplTest {

    @InjectMocks
    private GlobalSettingServiceImpl globalSettingService;

    @Mock
    private GlobalSettingRepository globalSettingRepository;

    @Mock
    private EntityManager entityManager;

    @Mock
    private User user;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateGlobalSetting_Success() throws Exception {
        // Arrange
        GlobalSetting globalSetting = new GlobalSetting();
        globalSetting.setName("Test Setting");
        globalSetting.setEnabled(true);

        when(globalSettingRepository.existsByName(globalSetting.getName())).thenReturn(false);
        when(globalSettingRepository.save(globalSetting)).thenReturn(globalSetting);

        // Act
        GlobalSetting result = globalSettingService.createGlobalSetting(globalSetting, user);

        // Assert
        assertNotNull(result);
        assertEquals(globalSetting.getName(), result.getName());
        verify(globalSettingRepository, times(1)).existsByName(globalSetting.getName());
        verify(globalSettingRepository, times(1)).save(globalSetting);
    }

    @Test
    public void testCreateGlobalSetting_NameAlreadyExists() throws Exception {
        // Arrange
        GlobalSetting globalSetting = new GlobalSetting();
        globalSetting.setName("Test Setting");

        when(globalSettingRepository.existsByName(globalSetting.getName())).thenReturn(true);

        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> {
            globalSettingService.createGlobalSetting(globalSetting, user);
        });
        assertEquals("name", exception.getMessage());
        verify(globalSettingRepository, times(1)).existsByName(globalSetting.getName());
    }

    @Test
    public void testEditGlobalSetting_Success() throws Exception {
        // Arrange
        GlobalSetting globalSetting = new GlobalSetting();
        globalSetting.setId(1L);
        globalSetting.setName("Updated Setting");

        GlobalSetting existingSetting = new GlobalSetting();
        existingSetting.setId(1L);
        existingSetting.setName("Old Setting");

        when(globalSettingRepository.findById(globalSetting.getId())).thenReturn(Optional.of(existingSetting));
        when(globalSettingRepository.save(globalSetting)).thenReturn(globalSetting);

        // Act
        GlobalSetting result = globalSettingService.editGlobalSetting(globalSetting, user);

        // Assert
        assertNotNull(result);
        assertEquals(globalSetting.getName(), result.getName());
        verify(globalSettingRepository, times(1)).findById(globalSetting.getId());
        verify(globalSettingRepository, times(1)).save(globalSetting);
    }

    @Test
    public void testEditGlobalSetting_NameAlreadyExists() throws Exception {
        // Arrange
        GlobalSetting globalSetting = new GlobalSetting();
        globalSetting.setId(1L);
        globalSetting.setName("Updated Setting");

        GlobalSetting existingSetting = new GlobalSetting();
        existingSetting.setId(1L);
        existingSetting.setName("Old Setting");

        when(globalSettingRepository.findById(globalSetting.getId())).thenReturn(Optional.of(existingSetting));
        when(globalSettingRepository.existsByName(globalSetting.getName())).thenReturn(true);

        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> {
            globalSettingService.editGlobalSetting(globalSetting, user);
        });
        assertEquals("name", exception.getMessage());
    }

    @Test
    public void testDisableGlobalSetting_Success() {
        // Arrange
        GlobalSetting globalSetting = new GlobalSetting();
        globalSetting.setId(1L);
        globalSetting.setName("Test Setting");

        when(globalSettingRepository.findById(globalSetting.getId())).thenReturn(Optional.of(globalSetting));
        when(globalSettingRepository.save(globalSetting)).thenReturn(globalSetting);

        // Act
        GlobalSetting result = globalSettingService.disableGlobalSetting(globalSetting.getId(), user);

        // Assert
        assertNotNull(result);
        assertTrue(result.getDisabledAt() != null);  // Assuming `setDisabledAt` is set during disable
        verify(globalSettingRepository, times(1)).findById(globalSetting.getId());
        verify(globalSettingRepository, times(1)).save(globalSetting);
    }

    @Test
    public void testDisableGlobalSetting_NotFound() {
        // Arrange
        Long id = 999L;

        when(globalSettingRepository.findById(id)).thenReturn(Optional.empty());

        // Act
        GlobalSetting result = globalSettingService.disableGlobalSetting(id, user);

        // Assert
        assertNull(result);
        verify(globalSettingRepository, times(1)).findById(id);
    }

    @Test
    public void testFindById_Success() {
        // Arrange
        Long id = 1L;
        GlobalSetting globalSetting = new GlobalSetting();
        globalSetting.setId(id);

        when(globalSettingRepository.findById(id)).thenReturn(Optional.of(globalSetting));

        // Act
        Optional<GlobalSetting> result = globalSettingService.findById(id);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(id, result.get().getId());
        verify(globalSettingRepository, times(1)).findById(id);
    }

    @Test
    public void testFindById_NotFound() {
        // Arrange
        Long id = 1L;

        when(globalSettingRepository.findById(id)).thenReturn(Optional.empty());

        // Act
        Optional<GlobalSetting> result = globalSettingService.findById(id);

        // Assert
        assertFalse(result.isPresent());
        verify(globalSettingRepository, times(1)).findById(id);
    }
}
