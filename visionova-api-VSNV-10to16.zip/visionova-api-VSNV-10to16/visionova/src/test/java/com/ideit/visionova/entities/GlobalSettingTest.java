package com.ideit.visionova.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;


class GlobalSettingTest {

    private GlobalSetting globalSetting;

    @BeforeEach
    void setUp() {
        globalSetting = new GlobalSetting();
    }

    @Test
    void testDefaultValues() {
        assertNotNull(globalSetting);
        assertNull(globalSetting.getId());
        assertNull(globalSetting.getName());
        assertNull(globalSetting.getValue());
        assertNull(globalSetting.getDescription());
        assertNull(globalSetting.getCreatedAt());
        assertNull(globalSetting.getCreatedBy());
        assertNull(globalSetting.getModifiedAt());
        assertNull(globalSetting.getModifiedBy());
        assertNull(globalSetting.getDisabledAt());
        assertNull(globalSetting.getDisabledBy());
        assertTrue(globalSetting.getEnabled());  // Default value is true
    }

    @Test
    void testSetAndGetName() {
        globalSetting.setName("Test Name");
        assertEquals("Test Name", globalSetting.getName());
    }

    @Test
    void testSetAndGetValue() {
        globalSetting.setValue("Test Value");
        assertEquals("Test Value", globalSetting.getValue());
    }

    @Test
    void testSetAndGetDescription() {
        globalSetting.setDescription("Test Description");
        assertEquals("Test Description", globalSetting.getDescription());
    }

    @Test
    void testSetAndGetEnabled() {
        globalSetting.setEnabled(false);
        assertFalse(globalSetting.getEnabled());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date date = new Date();
        globalSetting.setCreatedAt(date);
        assertEquals(date, globalSetting.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        User user = new User(); // Assuming User is a valid class
        globalSetting.setCreatedBy(user);
        assertEquals(user, globalSetting.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date date = new Date();
        globalSetting.setModifiedAt(date);
        assertEquals(date, globalSetting.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        User user = new User(); // Assuming User is a valid class
        globalSetting.setModifiedBy(user);
        assertEquals(user, globalSetting.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date date = new Date();
        globalSetting.setDisabledAt(date);
        assertEquals(date, globalSetting.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        User user = new User(); // Assuming User is a valid class
        globalSetting.setDisabledBy(user);
        assertEquals(user, globalSetting.getDisabledBy());
    }
}
