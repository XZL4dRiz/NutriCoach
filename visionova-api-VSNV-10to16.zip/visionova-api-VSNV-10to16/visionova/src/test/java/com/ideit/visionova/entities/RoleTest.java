package com.ideit.visionova.entities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class RoleTest {

    @Mock
    private User mockUser;

    private Role role;

    @BeforeEach
    public void setUp() {
        role = new Role();
    }

    @Test
    void testSetAndGetName() {
        role.setName("ADMIN");
        assertEquals("ADMIN", role.getName());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date now = new Date();
        role.setCreatedAt(now);
        assertEquals(now, role.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        role.setCreatedBy(mockUser);
        assertEquals(mockUser, role.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date now = new Date();
        role.setModifiedAt(now);
        assertEquals(now, role.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        role.setModifiedBy(mockUser);
        assertEquals(mockUser, role.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date now = new Date();
        role.setDisabledAt(now);
        assertEquals(now, role.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        role.setDisabledBy(mockUser);
        assertEquals(mockUser, role.getDisabledBy());
    }

    @Test
    void testSetAndGetEnabled() {
        role.setEnabled(false);
        assertFalse(role.getEnabled());
    }

    @Test
    void testToString() {
        role.setName("ADMIN");

        assertTrue(role.toString().contains("ADMIN"));
    }

    @Test
    void testEqualsAndHashCode() {
        Role anotherRole = new Role();
        anotherRole.setName("ADMIN");

        role.setName("ADMIN");

        assertEquals(role, anotherRole);
        assertEquals(role.hashCode(), anotherRole.hashCode());
    }
}
