package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.User;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional // Asegura que las transacciones se reviertan después de cada prueba
class UserServiceImplTest {

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private EntityManager entityManager;

    private User user;
    private User createdBy;

    @BeforeEach
    void setUp() {
        // Crear un usuario "creador" y un usuario de prueba
        createdBy = new User();
        createdBy.setLogin("admin");
        createdBy.setPassword("adminPassword");

        user = new User();
        user.setLogin("testUser");
        user.setPassword("password");

        // Usa merge en lugar de persist y deja que el EntityManager se encargue de la
        // asociación
        createdBy = entityManager.merge(createdBy);
        user = entityManager.merge(user);

        // Asegúrate de que los cambios se apliquen
        entityManager.flush();
    }

    @Test
    @Transactional
    void testCreateUser() {
        User newUser = new User();
        newUser.setLogin("newUser");
        newUser.setPassword("newPassword");

        User createdUser = userService.createUser(newUser, createdBy);

        assertNotNull(createdUser);
        assertEquals(newUser.getLogin(), createdUser.getLogin());
        assertNotNull(createdUser.getId());
    }

    @Test
    @Transactional
    void testModifyUser() {
        User modifiedUser = new User();
        modifiedUser.setId(user.getId());
        modifiedUser.setLogin("modifiedUser");
        modifiedUser.setPassword("newPassword");

        User updatedUser = userService.modifyUser(modifiedUser, createdBy);

        assertNotNull(updatedUser);
        assertEquals("modifiedUser", updatedUser.getLogin());
    }

    @Test
    @Transactional
    void testDisableUser() {
        User disabledUser = userService.disableUser(user, createdBy);

        assertNotNull(disabledUser);
        // Aquí podrías comprobar si los campos específicos relacionados con la
        // deshabilitación se actualizaron correctamente
    }

    @Test
    @Transactional
    void testFindById() {
        Optional<User> foundUser = userService.findById(user.getId());

        assertTrue(foundUser.isPresent());
        assertEquals(user.getLogin(), foundUser.get().getLogin());
    }
}