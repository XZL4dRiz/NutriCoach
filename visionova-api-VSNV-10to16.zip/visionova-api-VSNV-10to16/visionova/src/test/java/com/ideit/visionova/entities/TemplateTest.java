package com.ideit.visionova.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class TemplateTest {

    private Template template;

    @BeforeEach
    void setUp() {
        template = new Template();
    }

    @Test
    void testDefaultValues() {
        assertNotNull(template);
        assertNull(template.getId());
        assertNull(template.getTemplateName());
        assertNull(template.getCoordinates());
        assertNull(template.getCreatedAt());
        assertNull(template.getCreatedBy());
        assertNull(template.getModifiedAt());
        assertNull(template.getModifiedBy());
        assertNull(template.getDisabledAt());
        assertNull(template.getDisabledBy());
        assertTrue(template.getEnabled());  // Default value is true
    }

    @Test
    void testSetAndGetTemplateName() {
        template.setTemplateName("Test Template");
        assertEquals("Test Template", template.getTemplateName());
    }

    @Test
    void testSetAndGetCoordinates() {
        template.setCoordinates("x1,y1,x2,y2");
        assertEquals("x1,y1,x2,y2", template.getCoordinates());
    }

    @Test
    void testSetAndGetEnabled() {
        template.setEnabled(false);
        assertFalse(template.getEnabled());
    }

    @Test
    void testSetAndGetCreatedAt() {
        Date date = new Date();
        template.setCreatedAt(date);
        assertEquals(date, template.getCreatedAt());
    }

    @Test
    void testSetAndGetCreatedBy() {
        User user = new User(); // Assuming User is a valid class
        template.setCreatedBy(user);
        assertEquals(user, template.getCreatedBy());
    }

    @Test
    void testSetAndGetModifiedAt() {
        Date date = new Date();
        template.setModifiedAt(date);
        assertEquals(date, template.getModifiedAt());
    }

    @Test
    void testSetAndGetModifiedBy() {
        User user = new User(); // Assuming User is a valid class
        template.setModifiedBy(user);
        assertEquals(user, template.getModifiedBy());
    }

    @Test
    void testSetAndGetDisabledAt() {
        Date date = new Date();
        template.setDisabledAt(date);
        assertEquals(date, template.getDisabledAt());
    }

    @Test
    void testSetAndGetDisabledBy() {
        User user = new User(); // Assuming User is a valid class
        template.setDisabledBy(user);
        assertEquals(user, template.getDisabledBy());
    }
}
