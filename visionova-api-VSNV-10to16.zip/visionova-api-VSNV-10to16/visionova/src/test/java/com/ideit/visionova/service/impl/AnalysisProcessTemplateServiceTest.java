package com.ideit.visionova.service.impl;

import com.ideit.visionova.entities.AnalysisProcessTemplate;
import com.ideit.visionova.entities.User;
import com.ideit.visionova.repository.AnalysisProcessTemplateRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional // Asegura que las transacciones se reviertan despuÃ©s de cada prueba
class AnalysisProcessTemplateServiceImplTest {

    @Autowired
    private AnalysisProcessTemplateServiceImpl analysisProcessTemplateService;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private AnalysisProcessTemplateRepository analysisProcessTemplateRepository;

    private AnalysisProcessTemplate template;
    private User user;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setLogin("testUser");
        user.setPassword("password");

        // Persist the user entity to set it up for testing
        user = entityManager.merge(user);
        entityManager.flush();

        template = new AnalysisProcessTemplate();
        template.setParameters("Initial parameters");
        template.setCreatedAt(new Date());
        template.setCreatedBy(user);
    }

    @Test
    @Transactional
    void testCreateAnalysisProcessTemplate() {
        AnalysisProcessTemplate createdTemplate = analysisProcessTemplateService.createAnalysisProcessTemplate(template, user);

        assertNotNull(createdTemplate);
        assertEquals(template.getParameters(), createdTemplate.getParameters());
        assertNotNull(createdTemplate.getId());
    }

    @Test
    @Transactional
    void testModifyAnalysisProcessTemplate() {
        // Persist the initial template
        template = analysisProcessTemplateRepository.save(template);
        entityManager.flush();

        template.setParameters("Modified parameters");
        AnalysisProcessTemplate updatedTemplate = analysisProcessTemplateService.modifyAnalysisProcessTemplates(template, user);

        assertNotNull(updatedTemplate);
        assertEquals("Modified parameters", updatedTemplate.getParameters());
    }

    @Test
    @Transactional
    void testDisableAnalysisProcessTemplate() {
        // Persist the initial template
        template = analysisProcessTemplateRepository.save(template);
        entityManager.flush();

        AnalysisProcessTemplate disabledTemplate = analysisProcessTemplateService.disableAnalysisProcessTemplate(template, user);

        assertNotNull(disabledTemplate);
        // Here, you could add assertions to check if specific fields related to
        // disabling were updated correctly
    }

    @Test
    @Transactional
    void testFindById() {
        // Persist the initial template
        template = analysisProcessTemplateRepository.save(template);
        entityManager.flush();

        Optional<AnalysisProcessTemplate> foundTemplate = analysisProcessTemplateService.findById(template.getId());

        assertTrue(foundTemplate.isPresent());
        assertEquals(template.getParameters(), foundTemplate.get().getParameters());
    }
}